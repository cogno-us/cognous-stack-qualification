#!/usr/bin/env python3
"""Worker C compatibility / byte-identity probe (independent of the builder's tests and fixtures).

NOT YET RUN. Per the qualification protocol it must not be run against the candidate before the lead sends "PROTOCOL FROZEN"; until then only `py_compile` is allowed.

    python compat_probe.py --src <checkout>/src [--python <interpreter>] [--out result.json]
    python compat_probe.py --diff baseline.json candidate.json      # path-by-path comparison, no imports of any checkout

The probe imports the package from EXACTLY the given `src` directory in an isolated child interpreter (`-I`: no PYTHONPATH, no user site, no cwd on sys.path; `src` is put
first on sys.path and the child ABORTS if `agent_control_plane.__file__` does not live under it, which catches an editable install shadowing the intended tree).
It reads source files and computes values; it opens no network connection, writes no file inside any checkout (PYTHONDONTWRITEBYTECODE=1) and uses a fresh temp cwd.

Output (JSON, keys sorted):
  meta                      src path, python version, package file location
  protected_sha256          the seven protected evaluators (bounded, freshness, policy_binding, rule_revision, reversibility, holder_inventory, runtime_authority)
  all_modules_sha256        every *.py under src/agent_control_plane (an added module shows up as a new key)
  schema_files_sha256       every file under <repo>/schemas and <repo>/conformance (published JSON schemas / vectors / reason registries)
  reason_vocabulary         labels, REGISTRY_SHA256, CODES_ADDED_IN_0_2/0_3, the `codes` of each published reasons registry, vocabulary_for() samples, string constants of runtime_authority.py
  profile_fixtures          fixed RuntimeAuthorityProfile variants: model_dump JSON, its sha256, catalogue_digest (= commitment(profile.model_dump(mode="json")))
  approval_commitment       approval_commitment(profile, fixed context) per variant
  model_json_schemas_sha256 pydantic JSON schema sha256 of the persisted/profile models that exist in the tree
  effective_policy_snapshot identity_digest of a fixed EffectivePolicySnapshot, FAMILY_TABLE and SCHEMA_REVISIONS (additive growth of the two tables is EXPECTED at main)
  commitment_selfcheck      commitment() of fixed values (guards a changed canonicalisation)
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

PROTECTED = ("bounded", "freshness", "policy_binding", "rule_revision", "reversibility", "holder_inventory", "runtime_authority")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canon(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def child(src: str) -> dict:
    src_path = Path(src).resolve()
    sys.path.insert(0, str(src_path))
    import agent_control_plane  # noqa: E402

    pkg_dir = Path(agent_control_plane.__file__).resolve().parent
    if src_path not in pkg_dir.parents:
        raise SystemExit(f"ABORT: agent_control_plane imported from {pkg_dir}, not from {src_path}")
    repo = src_path.parent
    out: dict = {"meta": {"src": str(src_path), "package_dir": str(pkg_dir), "python": sys.version.split()[0]}}

    out["protected_sha256"] = {f"{n}.py": _sha(pkg_dir / f"{n}.py") for n in PROTECTED}
    out["all_modules_sha256"] = {p.name: _sha(p) for p in sorted(pkg_dir.glob("*.py"))}
    files = {}
    for sub in ("schemas", "conformance"):
        base = repo / sub
        if base.is_dir():
            for p in sorted(base.rglob("*")):
                if p.is_file():
                    files[str(p.relative_to(repo))] = _sha(p)
    out["schema_files_sha256"] = files

    import agent_control_plane.runtime_authority as ra  # noqa: E402
    from agent_control_plane.bounded import commitment  # noqa: E402

    out["commitment_selfcheck"] = {"a1": commitment({"a": 1}), "nested": commitment({"b": [1, 2, {"c": None}], "a": "x"}), "empty": commitment({})}

    # ---------------------------------------------------------------------------------------------------------------- reason vocabulary
    rv: dict = {}
    for name in ("VOCABULARY_VERSION", "VOCABULARY_VERSION_0_2", "VOCABULARY_VERSION_0_3"):
        rv[name] = getattr(ra, name, None)
    rv["REGISTRY_SHA256"] = dict(getattr(ra, "REGISTRY_SHA256", {}))
    rv["CODES_ADDED_IN_0_2"] = sorted(getattr(ra, "CODES_ADDED_IN_0_2", ()))
    rv["CODES_ADDED_IN_0_3"] = sorted(getattr(ra, "CODES_ADDED_IN_0_3", ()))
    reg_codes = {}
    for p in sorted((repo / "schemas").glob("runtime_authority_reasons_*.json")):
        doc = json.loads(p.read_text(encoding="utf-8"))
        codes = doc.get("codes", [])
        reg_codes[p.name] = {"count": len(codes), "sha256_of_codes_in_order": hashlib.sha256(_canon(codes).encode()).hexdigest(), "codes": codes}
    rv["published_registries"] = reg_codes
    samples = [["authorization_binding_changed"], ["check_expired_before_dispatch"], ["policy_binding_unsupported"], ["purpose_unreadable"], []]
    rv["vocabulary_for_samples"] = {",".join(s): ra.vocabulary_for(s) for s in samples}
    tree = ast.parse((pkg_dir / "runtime_authority.py").read_text(encoding="utf-8"))
    rv["runtime_authority_string_constants"] = sorted({n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)})
    out["reason_vocabulary"] = rv

    # ---------------------------------------------------------------------------------------------------------------- profile fixtures
    from agent_control_plane.freshness import FreshnessProfile  # noqa: E402

    key = "11" * 32
    actions = {"refund.issue": ra.ActionClass(class_id="t1", irreversible=True, max_status_age_seconds=30, on_unreadable="refuse"),
               "note.add": ra.ActionClass(class_id="t2", irreversible=False, max_status_age_seconds=60, on_unreadable="bounded_tolerance")}
    variants = {
        "minimal": dict(),
        "freshness_default": dict(freshness=FreshnessProfile()),
        "freshness_anchor": dict(freshness=FreshnessProfile(anchor_deadline_to_inputs=True, max_age_extension_seconds=100)),
    }
    profiles, commits, dumps = {}, {}, {}
    context = {"runtime_authority": {"profile": "runtime-authority/0.1", "required_inputs": [{"input_id": "g1", "input_type": "grant_status"}],
                                     "required_inputs_digest": commitment([{"input_id": "g1", "input_type": "grant_status"}])},
               "grant": {"purpose_ref": "purpose-1", "expires_at": "2030-01-01T00:00:00+00:00"}}
    for name, extra in variants.items():
        try:
            prof = ra.RuntimeAuthorityProfile(catalogue_version="probe-catalogue/1", actions=actions, producer_keys={"probe-producer": key}, allow_synthetic_resolver=True, **extra)
            dump = prof.model_dump(mode="json")
            dumps[name] = {"json": _canon(dump), "sha256": hashlib.sha256(_canon(dump).encode()).hexdigest(), "catalogue_digest": commitment(dump)}
            commits[name] = ra.approval_commitment(prof, context)
        except Exception as exc:  # recorded, never swallowed silently
            dumps[name] = {"error": type(exc).__name__ + ":" + str(exc)[:200]}
            commits[name] = {"error": type(exc).__name__}
    out["profile_fixtures"], out["approval_commitment"] = dumps, commits

    # ---------------------------------------------------------------------------------------------------------------- pydantic JSON schemas of persisted models
    import agent_control_plane.bounded as bounded  # noqa: E402

    models = {}
    for mod, names in ((bounded, ("RuntimeDecision", "TenantAuthorizationBinding", "EffectTimeRefusal", "EffectAttempt", "EffectObservation", "ResolutionInput", "ResolutionCheck", "RuntimeProposal", "ObservationPolicy")),
                       (ra, ("RuntimeAuthorityProfile", "ActionClass", "PurposeStatus"))):
        for n in names:
            cls = getattr(mod, n, None)
            if cls is None or not hasattr(cls, "model_json_schema"):
                continue
            try:
                models[f"{mod.__name__.rsplit('.', 1)[-1]}.{n}"] = hashlib.sha256(_canon(cls.model_json_schema()).encode()).hexdigest()
            except Exception as exc:
                models[f"{mod.__name__.rsplit('.', 1)[-1]}.{n}"] = "error:" + type(exc).__name__
    out["model_json_schemas_sha256"] = models

    # ---------------------------------------------------------------------------------------------------------------- EffectivePolicySnapshot
    eps: dict = {}
    try:
        from agent_control_plane import registry_effective_policy as eff  # noqa: E402

        fam = eff.AppliedFamily("class_age", "f5-action-class-age-bounds", "r08-v2", None, "sha256:" + "a" * 64, (("t1", 30),), "sel-1", 1)
        snap = eff.EffectivePolicySnapshot("sha256:" + "b" * 64, "sha256:" + "c" * 64, (fam,), (("consumer_id", "c"), ("tenant_id", "t"), ("action_id", "a"), ("operation_ids", ())), "2026-10-29T00:00:00+00:00")
        eps["identity_digest"] = snap.identity_digest
        snap0 = eff.EffectivePolicySnapshot(None, None, (), (), "2026-10-29T00:00:00+00:00")
        eps["identity_digest_empty"] = snap0.identity_digest
        eps["FAMILY_TABLE"] = {k: list(v) for k, v in sorted(eff.FAMILY_TABLE.items())}
        eps["SCHEMA_REVISIONS"] = dict(sorted(eff.SCHEMA_REVISIONS.items()))
    except Exception as exc:  # e.g. Registry pin not importable in this environment: recorded as UNVERIFIED for that part
        eps["error"] = type(exc).__name__ + ":" + str(exc)[:300]
    out["effective_policy_snapshot"] = eps
    return out


def flatten(obj, prefix=""):
    if isinstance(obj, dict):
        for k in sorted(obj):
            yield from flatten(obj[k], f"{prefix}/{k}")
    else:
        yield prefix, obj


def diff(a: dict, b: dict) -> dict:
    fa, fb = dict(flatten(a)), dict(flatten(b))
    return {"only_in_baseline": sorted(set(fa) - set(fb)), "only_in_candidate": sorted(set(fb) - set(fa)),
            "changed": {k: [fa[k], fb[k]] for k in sorted(set(fa) & set(fb)) if fa[k] != fb[k] and not k.startswith("/meta/")}}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src")
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--out")
    ap.add_argument("--diff", nargs=2)
    ap.add_argument("--child", action="store_true")
    ns = ap.parse_args()
    if ns.diff:
        a, b = (json.loads(Path(p).read_text()) for p in ns.diff)
        print(json.dumps(diff(a, b), indent=1, sort_keys=True))
        return 0
    if not ns.src:
        ap.error("--src is required")
    if ns.child:
        print(json.dumps(child(ns.src), sort_keys=True))
        return 0
    env = {"PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1"}
    with tempfile.TemporaryDirectory() as td:
        proc = subprocess.run([ns.python, "-I", str(Path(__file__).resolve()), "--child", "--src", ns.src], cwd=td, env=env, capture_output=True, text=True, timeout=600)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr[-4000:])
        return proc.returncode
    text = proc.stdout.strip().splitlines()[-1]
    json.loads(text)
    if ns.out:
        Path(ns.out).write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

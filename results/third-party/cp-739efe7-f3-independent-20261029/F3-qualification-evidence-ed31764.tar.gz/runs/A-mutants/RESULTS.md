# Worker A D06 mutants (PROPOSAL evidence; scratch copies under A-mutants/D06-Mnn/tree, PYTHONPATH=copy/src verified via acp path in each ev/f3a_evidence.jsonl)
Baseline (A-main3, 739efe7): 23 failed (22 pin-export A19 + A06 pin sub-check = DEV-PE-1), 73 passed. KILLED = extra failing cases vs baseline.
M01 execute-compare-deleted KILLED (43 new: A02 x8, A03, A04, A13, A17, A18, A19 execute ...)
M02 claim-stage-compare-deleted KILLED (4: A19_claim x3, A20)
M03 pin-export-compare-deleted KILLED (2: A09, A20)
M04 local-claim-issuance-compare-deleted KILLED (5: A09, A17_claim, A19_claim x3)
M05 ignore-identity-max-age KILLED (A02_live[identity_max_age])
M06 ignore-scope-authority-domain SURVIVED (no live-side authority-domain change in harness; persisted-side perturbation cannot distinguish a constant live value)
M07 ignore-family-effective-policy-digest SURVIVED (same reason; registry-value restarts also change f4_scalars so are refused anyway)
M08 ignore-family-contract-version SURVIVED (same reason)
M09 accept-unknown-version KILLED (A03)
M10 legacy-accepted-at-cutoff KILLED (A04)
M11 legacy-ignores-index SURVIVED (harness strips F4 member leaving runtime_authority={} whereas a legacy writer has None, so base equality refuses regardless; harness gap)
M12 legacy-without-cutoff KILLED (A04)
M13 invalid-member-as-legacy SURVIVED (outcome-equivalent per mutant note; base equality refuses)

## After AMEND-3/4 (harness A-main4 file; mutants re-run: M06 M07 M08 M11)
D06-M06 23 failed, 74 passed in 79.86s (0:01:19) new: 
D06-M06 new: 
D06-M07 new: test_A25_live_side_member_perturbation_rebuild 
D06-M08 new: test_A25_live_side_member_perturbation_rebuild 
D06-M11 new: test_A16_strip_member_at_or_past_cutoff 

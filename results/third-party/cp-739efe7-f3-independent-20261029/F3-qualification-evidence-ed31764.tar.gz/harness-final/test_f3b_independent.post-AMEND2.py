"""F3-B independent qualification harness (Worker B) -- D-07 protected temporal-enforcement correction in runtime_authority.py.

STATUS: DESIGNED AND WRITTEN, NEVER RUN (brief rule 3: no execution against the candidate before the lead says "PROTOCOL FROZEN").
Only py_compile has been applied to this file. Expected values below are derived from the oracle documents 03 (F3-B items 1-8) and 02 (sections 6 and 7)
and from my own reading of the source; they were NOT fitted to a run. If a first run disagrees, that disagreement is a FINDING, not a reason to edit an
expectation silently (record the original output first, CA06).

SUBJECT SELECTION
  F3B_SUBJECT_SRC   path to a ``src`` directory (parent contains ``tests/`` and ``schemas/``). The role is derived from the sha256 of
                    ``agent_control_plane/runtime_authority.py`` (predecessor 061a986 = a4b4ac36..., candidate main 739efe7 = 45a27db8...); any other hash is BLOCKED.
  F3B_PRED_SRC      (candidate run only) ``src`` dir of the predecessor, used by B10 (AST proof) and, via a subprocess ``dump``, by the comparison cases.
  F3B_PRED_DUMP     (alternative to F3B_PRED_SRC) JSON written by ``python test_f3b_independent.py dump OUT.json`` run under F3B_SUBJECT_SRC=predecessor.
  F3_EVIDENCE_DIR   directory for ``B_evidence.jsonl`` (default: ``<this dir>/evidence``).
TWO-PHASE USE (B14 and the comparison cases)
  phase 1: F3B_SUBJECT_SRC=<pred src> python test_f3b_independent.py dump pred.json ; same with <cand src> -> cand.json
  phase 2: python test_f3b_independent.py compare pred.json cand.json   (exit 0 only if no violation)
  or run pytest once per subject; the candidate run builds the predecessor dump itself when F3B_PRED_SRC (or F3B_PRED_DUMP) is set.
Clock model: injected fake wall clock (``bounded._now``) AND fake monotonic clock (``bounded._monotonic``); nothing sleeps; no network. Stalls are
applied once, inside ``destination.observe`` (between the effect check and the dispatch gate). The only imports from the subject's ``tests/`` package are
pre-existing fixture helpers (setup_flow, reversibility flow/cls/outage, stale_grant, authority, policy-binding adopt/binding); none of the D-07
authored test files or fixtures is imported.

Markers: failures are reported as ``FAIL: ...``; an unrunnable environment as ``BLOCKED: ...``. There is no pytest.skip anywhere.
Per-subject expectations are explicit (PRED / CAND dictionaries); no assertion is conditional on "whatever the subject does".
"""
import ast
import difflib
import hashlib
import importlib
import json
import os
import random
import re
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRED_SHA = "a4b4ac36cca6e75d8fc3408b8738163acfb609a7265633aec2f799700ff9ea66"
CAND_SHA = "45a27db8695ff9d23516e1937f3bafa2391bbc1587ed0fb09f56ea8f3e01d23f"
# git blob ids of the six OTHER protected evaluators; identical at 061a986 and 739efe7 (read with git rev-parse before any execution)
PROTECTED_BLOBS = {
    "bounded.py": "2cc8d998ff0a8fec3112a8b0634111fcf8fbef17",
    "freshness.py": "0c4647f69ed5bb52d8e1e0e607faf6da061634f2",
    "policy_binding.py": "426d47797e92f19690a21b4e8b5dc1c35d1b579c",
    "rule_revision.py": "9ca71a8db3f790b0dde3127c4f34b563463859cb",
    "reversibility.py": "a6be4bfe555d16b7d40289cef113ae156fd8c843",
    "holder_inventory.py": "248e930437cd6dec682a43bb626ceccf83804b68",
}
CODE = "check_expired_before_dispatch"
PURPOSE_KINDS = ("live_irr", "live_rev", "cached_rev")
ALL_KINDS = ("live_irr", "live_rev", "cached_rev", "grant", "identity", "mandate")


# ------------------------------------------------------------------------------------------------ subject loading
class _Subject:
    pass


_S = None
_S_ERR = None


def _blob_id(data: bytes) -> str:
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _load():
    """Import the subject once. Sets _S or _S_ERR (never raises)."""
    global _S, _S_ERR
    if _S is not None or _S_ERR is not None:
        return
    try:
        raw = os.environ.get("F3B_SUBJECT_SRC")
        if not raw:
            raise RuntimeError("F3B_SUBJECT_SRC is not set")
        src = Path(raw).resolve()
        ra = src / "agent_control_plane" / "runtime_authority.py"
        if not ra.is_file():
            raise RuntimeError("no agent_control_plane/runtime_authority.py under %s" % src)
        sha = hashlib.sha256(ra.read_bytes()).hexdigest()
        role = {PRED_SHA: "predecessor", CAND_SHA: "candidate"}.get(sha)
        if role is None:
            raise RuntimeError("runtime_authority.py sha256 %s is neither the frozen predecessor nor the frozen candidate" % sha)
        for k in [k for k in sys.modules if k == "agent_control_plane" or k.startswith("agent_control_plane.") or k == "tests" or k.startswith("tests.")]:
            del sys.modules[k]
        sys.path[:0] = [str(src.parent), str(src)]
        s = _Subject()
        s.src, s.root, s.role, s.sha = src, src.parent, role, sha
        s.bounded = importlib.import_module("agent_control_plane.bounded")
        loc = Path(s.bounded.__file__).resolve()
        if src not in loc.parents:
            raise RuntimeError("agent_control_plane was imported from %s, not from the subject %s" % (loc, src))
        s.ra = importlib.import_module("tests.test_runtime_authority")
        s.rev = importlib.import_module("tests.test_reversibility")
        s.fr = importlib.import_module("tests.test_freshness")
        s.pb = importlib.import_module("tests.test_policy_binding_approval_generation")
        s.ba = importlib.import_module("tests.test_bounded_authorization")
        s.NOW = s.ba.NOW
        s.FreshnessProfile = importlib.import_module("agent_control_plane.freshness").FreshnessProfile
        s.AgeExtensionRefused = importlib.import_module("agent_control_plane.freshness").AgeExtensionRefused
        s.runtime_authority = importlib.import_module("agent_control_plane.runtime_authority")
        _S = s
    except Exception as exc:  # noqa: BLE001 - reported as BLOCKED by the fixture
        _S_ERR = "%s: %s" % (type(exc).__name__, exc)


def blocked(msg):
    import pytest
    pytest.fail("BLOCKED: " + msg, pytrace=False)


def fail(msg):
    import pytest
    pytest.fail("FAIL: " + msg, pytrace=False)


def subject():
    _load()
    if _S is None:
        blocked(_S_ERR)
    return _S


# ------------------------------------------------------------------------------------------------ evidence
def ev(case, **data):
    d = Path(os.environ.get("F3_EVIDENCE_DIR") or (HERE / "evidence"))
    d.mkdir(parents=True, exist_ok=True)
    role = _S.role if _S else "unloaded"
    with open(d / "B_evidence.jsonl", "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"worker": "B", "case": case, "role": role, "subject_sha256": _S.sha if _S else None, **data},
                            sort_keys=True, default=str) + "\n")


# ------------------------------------------------------------------------------------------------ fake clocks
class World:
    """Fake wall clock + fake monotonic clock. ``advance`` modes: coupled (both), wall_only, mono_only, wall_back (wall minus, mono untouched)."""

    def __init__(self, now):
        self.start = now
        self.wall = now
        self.mono = 1000.0

    def __call__(self):
        return self.wall

    def mono_fn(self):
        return self.mono

    def advance(self, seconds, mode="coupled"):
        if mode in ("coupled", "wall_only"):
            self.wall = self.wall + timedelta(seconds=seconds)
        if mode in ("coupled", "mono_only"):
            self.mono += seconds
        if mode == "wall_back":
            self.wall = self.wall - timedelta(seconds=seconds)


@contextmanager
def clocks(S, world):
    old = (S.bounded._now, S.bounded._monotonic)
    S.bounded._now, S.bounded._monotonic = world, world.mono_fn
    try:
        yield
    finally:
        S.bounded._now, S.bounded._monotonic = old


# ------------------------------------------------------------------------------------------------ scenario builder
def _narrow(p, c, ceil):
    cl = c.actions[p.action_id].model_copy(update={"max_status_age_seconds": ceil})
    return c.model_copy(update={"actions": {p.action_id: cl}})


def build(S, tmp, spec):
    """spec keys: kind, ceil, age, mode (anchor | anchor_binding | flag_false | nofresh), ext_to (optional), ext_limit (optional)."""
    kind, ceil, age, mode = spec["kind"], spec["ceil"], spec["age"], spec["mode"]
    NOW = S.NOW
    at = (NOW - timedelta(seconds=age)).isoformat()
    if kind == "cached_rev":
        p, r, f, c = S.rev.flow(tmp, S.rev.cls("reversible_until", max_status_age_seconds=ceil))
        r.cached.observed_at = at
        S.rev.outage(r)
    elif kind in ("live_irr", "live_rev"):
        p, r, f, c = S.ra.setup_flow(tmp, purpose=True, reversible=(kind == "live_rev"))
        c = _narrow(p, c, ceil)
        r.purpose.observed_at = at
    elif kind in ("grant", "identity", "mandate"):
        p, r, f, c = S.ra.setup_flow(tmp)
        c = _narrow(p, c, ceil)
        if kind == "grant":
            S.fr.stale_grant(r, age)
        else:
            setattr(f, kind + "_max_age_seconds", ceil)
            for item in (r.identities if kind == "identity" else r.mandates).values():
                item.observed_at = at
    elif kind in ("grant_revprof_irr", "grant_revprof_rev"):
        value = "irreversible" if kind.endswith("irr") else "reversible_until"
        p, r, f, c = S.rev.flow(tmp, S.rev.cls(value, max_status_age_seconds=ceil))
        S.fr.stale_grant(r, age)
    else:
        raise ValueError("unknown kind " + kind)
    ext_to = spec.get("ext_to")
    ext_limit = spec.get("ext_limit", (ext_to - ceil + 10) if ext_to else 0)
    if mode == "nofresh":
        cfg = c
        S.ra.bind_approval(r, cfg)
        f.runtime_authority_profile = cfg.snapshot()
    else:
        fresh = S.FreshnessProfile(max_age_extension_seconds=ext_limit, anchor_deadline_to_inputs=(mode != "flag_false"))
        if mode == "anchor_binding":
            S.pb.adopt(r, f, c, S.pb.binding(age_ceilings={p.action_id: ceil}), freshness=fresh)
            assert f.runtime_authority_profile.policy_binding is not None
        else:
            cfg = c.model_copy(update={"freshness": fresh})
            S.ra.bind_approval(r, cfg)
            f.runtime_authority_profile = cfg.snapshot()
            assert f.runtime_authority_profile.policy_binding is None
    if ext_to:
        S.fr.authority(f, r)
        class_id = f.runtime_authority_profile.actions[p.action_id].class_id
        f.record_age_extension(class_id=class_id, to_max_age_seconds=ext_to, not_before=NOW.isoformat(),
                               expires_at=(NOW + timedelta(hours=1)).isoformat(), outage_ref="outage-1", requested_by=S.fr.OTHER,
                               signer=S.fr.SIGNER, authority_ref="urn:cognous:authority:outage-1", now=NOW)
    return p, r, f


_UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
_HEX32 = re.compile(r"\b[0-9a-f]{32}\b")


def normalize_doc(text):
    """Persisted run document with random ids, pids and owners masked; everything else (keys, instants) kept. Returns canonical JSON text."""
    def walk(node, key=None):
        if isinstance(node, dict):
            return {k: walk(v, k) for k, v in node.items()}
        if isinstance(node, list):
            return [walk(v, key) for v in node]
        if key in ("pid", "owner", "host", "hostname", "process_id", "boot_id"):
            return "<masked>"
        if isinstance(node, str):
            return _HEX32.sub("<hex32>", _UUID.sub("<uuid>", node))
        return node
    return json.dumps(walk(json.loads(text)), sort_keys=True, separators=(",", ":"))


def key_paths(doc_text):
    out = set()

    def walk(node, prefix):
        if isinstance(node, dict):
            for k, v in node.items():
                out.add(prefix + "/" + k)
                walk(v, prefix + "/" + k)
        elif isinstance(node, list):
            for v in node:
                walk(v, prefix + "[]")
    walk(json.loads(doc_text), "")
    return sorted(out)


def _offset(S, ts):
    return None if ts is None else (datetime.fromisoformat(ts) - S.NOW).total_seconds()


def run_scenario(S, tmp, spec):
    """Decide at NOW, apply the stall steps once before dispatch, execute (and optionally retry). Plain-data outcome. Never raises."""
    world = World(S.NOW)
    steps = spec.get("steps") or [(spec.get("stall_mode", "coupled"), spec.get("stall", 0))]
    out = {}
    try:
        with clocks(S, world):
            try:
                p, r, f = build(S, Path(tmp), spec)
            except S.AgeExtensionRefused as exc:
                return {"extension_refused": sorted(getattr(exc, "reasons", [])), "decision": "n/a"}
            d = f.decide(p, now=S.NOW)
            out.update(decision=d.result, decision_reasons=sorted(d.reasons))
            if d.result != "authorized":
                return out
            calls = []
            real_apply = f.destination.apply
            f.destination.apply = lambda *a, **k: (calls.append(1), real_apply(*a, **k))[1]
            original, seen = f.destination.observe, []

            def stalled(effect_id):
                seen.append(1)
                if len(seen) == 1:
                    for mode, seconds in steps:
                        world.advance(seconds, mode)
                return original(effect_id).model_copy(update={"observed_at": S.NOW.isoformat()})
            f.destination.observe = stalled
            try:
                attempt, _ = f.execute(p, d, adapter_id=p.adapter_id, now=S.NOW)
                out.update(outcome="dispatched" if attempt.status == "acknowledged" else attempt.status, error=None)
            except PermissionError as exc:
                out.update(outcome="refused", error=str(exc))
            out["apply_calls"] = len(calls)
            out["destination_effects"] = len(f.destination.snapshot()["effects"])
            rec = f.records.load()
            done = [e for e in rec.check_events if e.phase == "completed"]
            if done:
                last = done[-1]
                opened = [e for e in rec.check_events if e.check_id == last.check_id and e.phase == "opened"]
                out["deadline_offset_s"] = _offset(S, last.deadline)
                out["opening_offset_s"] = _offset(S, opened[0].deadline) if opened else None
            out["refusal_reasons"] = sorted({x for ref in rec.refusals for x in getattr(ref, "reasons", [])})
            out["refusal_count"] = len(rec.refusals)
            out["attempt_statuses"] = sorted(a.status for a in rec.attempts)
            out["wall_elapsed_s"] = (world.wall - S.NOW).total_seconds()
            text = f.records.path.read_text(encoding="utf-8")
            out["doc_sha256"] = hashlib.sha256(normalize_doc(text).encode()).hexdigest()
            out["_doc_key_paths"] = key_paths(text) if spec.get("want_keys") else None
            if spec.get("retry") and out["outcome"] == "refused":
                before = len(calls)
                try:
                    a2, _ = f.execute(p, d, adapter_id=p.adapter_id, now=world.wall)
                    out["retry"] = "dispatched" if a2.status == "acknowledged" else a2.status
                except PermissionError as exc:
                    out["retry"] = "refused"
                    out["retry_error"] = str(exc)
                out["retry_apply_calls"] = len(calls) - before
    except Exception as exc:  # noqa: BLE001
        out["harness_error"] = "%s: %s" % (type(exc).__name__, exc)
    return out


def S_run(S, spec):
    with tempfile.TemporaryDirectory(prefix="f3b_") as tmp:
        res = run_scenario(S, tmp, spec)
    if "harness_error" in res:
        res.setdefault("decision", "harness_error")
    return res


# ------------------------------------------------------------------------------------------------ independent analytic oracle
def oracle(spec, role):
    """Expected (authorized?, deadline offset s, outcome) for a spec WITHOUT an extension, from the contract only (strict '>' wall and mono rules,
    deadline = min(opened + class bound, observed_at + own bound over the anchored inputs)). Purpose is anchored by the candidate in every anchored
    mode and by the predecessor only when a PolicyBinding is present (the very defect). Returns dict(authorized, offset, outcome)."""
    kind, ceil, age, mode = spec["kind"], spec["ceil"], spec["age"], spec["mode"]
    assert not spec.get("ext_to")
    authorized = 0 <= age <= ceil
    if mode == "nofresh":
        offset = None
    else:
        offset = float(ceil)
        anchored_mode = mode in ("anchor", "anchor_binding")
        purpose = kind in PURPOSE_KINDS
        if anchored_mode:
            offset = min(offset, 60.0)  # identity/mandate/approval/status inputs sit at NOW with their 60 s constructor defaults and are anchored too
        if anchored_mode and (not purpose or role == "candidate" or mode == "anchor_binding"):
            offset = min(offset, float(ceil - age))
    steps = spec.get("steps") or [(spec.get("stall_mode", "coupled"), spec.get("stall", 0))]
    wall = sum(s for m, s in steps if m in ("coupled", "wall_only")) - sum(s for m, s in steps if m == "wall_back")
    mono = sum(s for m, s in steps if m in ("coupled", "mono_only"))
    if offset is None:
        outcome = "dispatched"
    else:
        outcome = "refused" if (wall > offset or mono > max(offset, 0.0)) else "dispatched"
    return {"authorized": authorized, "offset": offset, "outcome": outcome if authorized else "held"}


def check_against_oracle(spec, got, role):
    o = oracle(spec, role)
    errs = []
    if (got.get("decision") == "authorized") != o["authorized"]:
        errs.append("decision %r vs oracle authorized=%r" % (got.get("decision"), o["authorized"]))
    elif o["authorized"]:
        if got.get("outcome") != o["outcome"]:
            errs.append("outcome %r vs oracle %r" % (got.get("outcome"), o["outcome"]))
        if got.get("deadline_offset_s") != o["offset"]:
            errs.append("deadline_offset_s %r vs oracle %r" % (got.get("deadline_offset_s"), o["offset"]))
    return errs


# ------------------------------------------------------------------------------------------------ dump (phase 1) and comparison (phase 2)
def grid_specs():
    """>= 600 deterministic inputs (seed fixed). Every spec carries an id."""
    rnd = random.Random(0xF3B07)
    modes = ["anchor"] * 4 + ["anchor_binding", "flag_false", "nofresh"]
    specs = []
    for i in range(640):
        kind = rnd.choice(ALL_KINDS)
        ceil = rnd.choice([20, 30, 45, 60, 90])
        age = rnd.choice([0, rnd.randint(0, ceil), ceil, ceil - 1, ceil // 2, ceil + 1])
        mode = rnd.choice(modes)
        if mode == "anchor_binding" and kind in ("identity", "mandate"):
            mode = "anchor"
        rem = ceil - age
        stall = rnd.choice([0, max(rem - 1, 0), max(rem, 0), max(rem + 1, 0), ceil - 1, ceil, ceil + 1, rnd.randint(0, 2 * ceil)])
        specs.append({"id": "g%04d" % i, "kind": kind, "ceil": ceil, "age": age, "mode": mode, "stall": stall})
    return specs


def _file_hashes(S):
    out = {"protected_blobs": {}, "schemas_sha256": {}}
    for name in PROTECTED_BLOBS:
        out["protected_blobs"][name] = _blob_id((S.src / "agent_control_plane" / name).read_bytes())
    sch = S.root / "schemas"
    if sch.is_dir():
        for p in sorted(sch.rglob("*")):
            if p.is_file():
                out["schemas_sha256"][str(p.relative_to(sch))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def string_constants(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    return sorted({n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)})


def _commitments(S):
    from agent_control_plane.bounded import commitment
    out = {}
    with tempfile.TemporaryDirectory(prefix="f3b_c_") as tmp:
        p, r, f, c = S.ra.setup_flow(Path(tmp), purpose=True)
        ctx = r.contexts[S.ba.PROFILE]
        variants = {
            "default": c,
            "fresh_plain": c.model_copy(update={"freshness": S.FreshnessProfile(max_age_extension_seconds=0)}),
            "fresh_anchored": c.model_copy(update={"freshness": S.FreshnessProfile(max_age_extension_seconds=0, anchor_deadline_to_inputs=True)}),
            "fresh_anchored_ext": c.model_copy(update={"freshness": S.FreshnessProfile(max_age_extension_seconds=300, anchor_deadline_to_inputs=True)}),
            "with_binding": c.model_copy(update={"policy_binding": S.pb.binding(age_ceilings={p.action_id: 60}),
                                                 "freshness": S.FreshnessProfile(max_age_extension_seconds=0, anchor_deadline_to_inputs=True)}),
        }
        for name, cfg in variants.items():
            out[name] = {"approval_commitment": S.runtime_authority.approval_commitment(cfg, ctx),
                         "catalogue_digest": commitment(cfg.model_dump(mode="json")),
                         "profile_dump_sha256": hashlib.sha256(json.dumps(cfg.model_dump(mode="json"), sort_keys=True,
                                                                          separators=(",", ":")).encode()).hexdigest()}
    return out


_DUMP_CACHE = {}


def make_dump(S):
    key = S.sha
    if key in _DUMP_CACHE:
        return _DUMP_CACHE[key]
    specs = grid_specs()
    results = {}
    for spec in specs:
        results[spec["id"]] = {"spec": spec, "res": S_run(S, spec)}
    for name, extra in {"refusal_class_deadline": dict(kind="live_irr", ceil=30, age=0, stall=31, mode="anchor"),
                        "refusal_changed_case": dict(kind="live_irr", ceil=30, age=30, stall=29, mode="anchor"),
                        "refusal_grant_anchored": dict(kind="grant", ceil=30, age=20, stall=11, mode="anchor")}.items():
        spec = dict(extra, id=name, want_keys=True)
        results[name] = {"spec": spec, "res": S_run(S, spec)}
    dump = {"role": S.role, "sha256": S.sha, "results": results, "static": {**_file_hashes(S), "string_constants": string_constants(
        S.src / "agent_control_plane" / "runtime_authority.py"), "commitments": _commitments(S)}}
    _DUMP_CACHE[key] = dump
    return dump


def violations_property(pred, cand):
    """B14 core. Returns (list of violations, stats). Input = same spec id in both dumps."""
    bad, stats = [], {"n": 0, "tighter": 0, "newly_refused": 0, "errors": 0}
    for sid, c in cand["results"].items():
        pr = pred["results"].get(sid)
        if pr is None or not sid.startswith("g"):
            continue
        a, b = pr["res"], c["res"]
        if "harness_error" in a or "harness_error" in b:
            stats["errors"] += 1
            continue
        stats["n"] += 1
        if a.get("decision") != b.get("decision") or a.get("decision_reasons") != b.get("decision_reasons"):
            bad.append("%s decision changed %r -> %r" % (sid, a.get("decision_reasons"), b.get("decision_reasons")))
            continue
        if b.get("decision") != "authorized":
            continue
        da, db = a.get("deadline_offset_s"), b.get("deadline_offset_s")
        if da is not None and (db is None or db > da):
            bad.append("%s new deadline %r > old %r" % (sid, db, da))
        if da is not None and db is not None and db < da:
            stats["tighter"] += 1
        if b.get("outcome") == "dispatched" and a.get("outcome") != "dispatched":
            bad.append("%s NEW PERMISSION: candidate dispatched, predecessor %r" % (sid, a.get("outcome")))
        if a.get("outcome") == "dispatched" and b.get("outcome") == "refused":
            stats["newly_refused"] += 1
        if b.get("apply_calls", 0) > a.get("apply_calls", 0):
            bad.append("%s apply called more often by candidate" % sid)
    return bad, stats


def get_pred_dump(S):
    if S.role == "predecessor":
        return make_dump(S)
    path = os.environ.get("F3B_PRED_DUMP")
    if path:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    pred_src = os.environ.get("F3B_PRED_SRC")
    if pred_src:
        out = Path(tempfile.mkdtemp(prefix="f3b_pred_")) / "pred.json"
        env = dict(os.environ, F3B_SUBJECT_SRC=pred_src, PYTHONDONTWRITEBYTECODE="1")
        env.pop("F3B_PRED_SRC", None)
        proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), "dump", str(out)], env=env, capture_output=True, text=True, timeout=3000)
        if proc.returncode != 0 or not out.is_file():
            blocked("predecessor dump subprocess failed: rc=%s stderr=%s" % (proc.returncode, proc.stderr[-1500:]))
        return json.loads(out.read_text(encoding="utf-8"))
    blocked("candidate comparison needs F3B_PRED_SRC or F3B_PRED_DUMP (predecessor dump)")


# ------------------------------------------------------------------------------------------------ per-subject expectation helper
def expect(S, case, spec, pred, cand, want_keys=()):
    """Run ``spec`` and compare the subject's result to ITS explicit expectation (``pred`` for the predecessor, ``cand`` for the candidate).
    Both are dicts of result keys -> exact expected value. Records evidence either way."""
    exp = pred if S.role == "predecessor" else cand
    res = S_run(S, spec)
    ev(case, spec=spec, expected=exp, result={k: v for k, v in res.items() if not k.startswith("_")})
    if "harness_error" in res:
        blocked("%s harness error %s" % (case, res["harness_error"]))
    errs = ["%s: got %r expected %r" % (k, res.get(k), v) for k, v in exp.items()
            if not ((v in (res.get(k) or "")) if k == "error" else res.get(k) == v)]
    if errs:
        fail("%s [%s] spec=%s :: %s" % (case, S.role, json.dumps(spec, sort_keys=True), "; ".join(errs)))
    return res


D, R, H = "dispatched", "refused", "held"


# ================================================================================================ B01 .. B10  (contract E1, E2, E5, E7, E8)
def test_B01_live_purpose_irreversible_stall_beyond_window_no_binding():
    """E1. Frozen expectation (03 F3-B 1 / 02 s.6): flag on, no PolicyBinding, class bound 60, live purpose observation age 40 at evaluation
    (window 20), 21 s stall (purpose age 61 at dispatch, 1 s over the ceiling). PASS iff: predecessor DISPATCHES (apply 1, deadline offset 60);
    candidate REFUSES with the existing check_expired_before_dispatch, apply 0, no destination effect, deadline offset 20."""
    s = subject()
    expect(s, "B01", dict(kind="live_irr", ceil=60, age=40, stall=21, mode="anchor"),
           pred=dict(decision="authorized", outcome=D, apply_calls=1, destination_effects=1, deadline_offset_s=60.0),
           cand=dict(decision="authorized", outcome=R, error=CODE, apply_calls=0, destination_effects=0, deadline_offset_s=20.0,
                     refusal_reasons=[CODE]))


def test_B02_live_purpose_reversible_class_same_defect():
    """E1/E2. Same as B01 on a reversible class (on_unreadable bounded_tolerance). PASS iff predecessor DISPATCHES and candidate REFUSES
    (code check_expired_before_dispatch, apply 0, offset 20)."""
    s = subject()
    expect(s, "B02", dict(kind="live_rev", ceil=60, age=40, stall=21, mode="anchor"),
           pred=dict(decision="authorized", outcome=D, apply_calls=1, deadline_offset_s=60.0),
           cand=dict(decision="authorized", outcome=R, error=CODE, apply_calls=0, deadline_offset_s=20.0))


def test_B03_former_end_of_window_and_class_deadline_still_refuses():
    """E1. Ceiling 30, purpose age 30 (window 0). Stall 30 (former end of the unanchored window, purpose age 60): predecessor DISPATCHES, candidate
    REFUSES. Stall 31 (past the class deadline): BOTH refuse. PASS iff all three outcomes (stall 30 pred D / cand R; stall 31 pred R / cand R)."""
    s = subject()
    expect(s, "B03a", dict(kind="live_irr", ceil=30, age=30, stall=30, mode="anchor"), pred=dict(outcome=D, apply_calls=1), cand=dict(outcome=R, apply_calls=0))
    expect(s, "B03b", dict(kind="live_irr", ceil=30, age=30, stall=31, mode="anchor"), pred=dict(outcome=R, apply_calls=0), cand=dict(outcome=R, apply_calls=0))


def test_B04_grant_status_anchoring_unchanged():
    """E2 control. Grant status age 20, bound 30 (window 10), flag on, no binding. PASS iff BOTH subjects: stall 10 dispatched, stall 11 refused
    (strict >), deadline offset 10."""
    s = subject()
    for st, o in ((9, D), (10, D), (11, R)):
        expect(s, "B04_stall%d" % st, dict(kind="grant", ceil=30, age=20, stall=st, mode="anchor"),
               pred=dict(outcome=o, deadline_offset_s=10.0), cand=dict(outcome=o, deadline_offset_s=10.0))


def test_B05_identity_anchoring_unchanged():
    """E2 control. Identity observation age 20 with identity_max_age_seconds 30. PASS iff both subjects: stall 10 dispatched, 11 refused, offset 10."""
    s = subject()
    for st, o in ((10, D), (11, R)):
        expect(s, "B05_stall%d" % st, dict(kind="identity", ceil=30, age=20, stall=st, mode="anchor"),
               pred=dict(outcome=o, deadline_offset_s=10.0), cand=dict(outcome=o, deadline_offset_s=10.0))


def test_B06_mandate_anchoring_unchanged():
    """E2 control. Mandate observation age 20 with mandate_max_age_seconds 30. PASS iff both subjects: stall 10 dispatched, 11 refused, offset 10."""
    s = subject()
    for st, o in ((10, D), (11, R)):
        expect(s, "B06_stall%d" % st, dict(kind="mandate", ceil=30, age=20, stall=st, mode="anchor"),
               pred=dict(outcome=o, deadline_offset_s=10.0), cand=dict(outcome=o, deadline_offset_s=10.0))


def test_B07_irreversible_and_post_reversal_window_cached_snapshot_still_held():
    """E2. A cached purpose snapshot must NOT stand in for an unreadable purpose for (a) an irreversible class and (b) a reversible_until class whose
    window has passed. PASS iff BOTH subjects HOLD at the decision, with no attempt and no destination effect (the anchor change cannot make a
    cache acceptable)."""
    s = subject()
    from datetime import timedelta as td
    for name in ("irreversible", "window_passed"):
        world = World(s.NOW)
        with tempfile.TemporaryDirectory(prefix="f3b_b07_") as tmp, clocks(s, world):
            if name == "irreversible":
                p, r, f, c = s.rev.flow(Path(tmp), s.rev.cls("irreversible"))
            else:
                p, r, f, c = s.rev.flow(Path(tmp), s.rev.cls("reversible_until", reversible_until=(s.NOW - td(minutes=1)).isoformat()))
            r.cached.observed_at = (s.NOW - td(seconds=5)).isoformat()
            s.rev.outage(r)
            cfg = c.model_copy(update={"freshness": s.FreshnessProfile(max_age_extension_seconds=0, anchor_deadline_to_inputs=True)})
            s.ra.bind_approval(r, cfg)
            f.runtime_authority_profile = cfg.snapshot()
            d = f.decide(p, now=s.NOW)
            rec = f.records.load()
            res = {"decision": d.result, "reasons": sorted(d.reasons), "attempts": len(rec.attempts), "effects": len(f.destination.snapshot()["effects"])}
        ev("B07_" + name, result=res)
        if d.result == "authorized" or res["attempts"] or res["effects"]:
            fail("B07 %s [%s] not held: %s" % (name, s.role, res))


def test_B08_recorded_deadline_is_the_purpose_anchor():
    """E1/E4. Ceiling 30, purpose age 20, flag on, no binding, no stall. The persisted deadline of the dispatch check is min(opened+30, observed+30).
    PASS iff predecessor offset == 30 and candidate offset == 10; opening deadline offset == 30 on both (the opening is untouched)."""
    s = subject()
    expect(s, "B08", dict(kind="live_irr", ceil=30, age=20, stall=0, mode="anchor"),
           pred=dict(outcome=D, deadline_offset_s=30.0, opening_offset_s=30.0), cand=dict(outcome=D, deadline_offset_s=10.0, opening_offset_s=30.0))


def test_B09_policy_binding_path_unchanged():
    """E8/E2. With a PolicyBinding the purpose anchor existed before the change. Ceiling 30, purpose age 30, stall 29. PASS iff BOTH subjects
    REFUSE with check_expired_before_dispatch, apply 0, offset 0 (byte-identical outcome); and live age 20 stall 10/11 -> dispatched/refused on both."""
    s = subject()
    both = dict(outcome=R, error=CODE, apply_calls=0, deadline_offset_s=0.0)
    expect(s, "B09a", dict(kind="live_irr", ceil=30, age=30, stall=29, mode="anchor_binding"), pred=both, cand=both)
    expect(s, "B09b", dict(kind="live_irr", ceil=30, age=20, stall=10, mode="anchor_binding"), pred=dict(outcome=D), cand=dict(outcome=D))
    expect(s, "B09c", dict(kind="live_irr", ceil=30, age=20, stall=11, mode="anchor_binding"), pred=dict(outcome=R), cand=dict(outcome=R))


def _ast_unwrap_guard(tree):
    """Replace every ``if binding is not None:`` whose body imports _FRESH_DEADLINES by its body (the predecessor shape -> candidate shape)."""
    class T(ast.NodeTransformer):
        def visit_If(self, node):
            self.generic_visit(node)
            t = node.test
            is_guard = (isinstance(t, ast.Compare) and isinstance(t.left, ast.Name) and t.left.id == "binding" and len(t.ops) == 1
                        and isinstance(t.ops[0], ast.IsNot) and isinstance(t.comparators[0], ast.Constant) and t.comparators[0].value is None)
            has_import = any(isinstance(n, ast.ImportFrom) and any(a.name == "_FRESH_DEADLINES" for a in n.names) for b in node.body for n in ast.walk(b))
            return node.body if (is_guard and has_import and not node.orelse) else node
    return ast.fix_missing_locations(T().visit(tree))


def _count_guards(tree):
    n = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.If) and isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == "binding" \
                and any(isinstance(m, ast.ImportFrom) and any(a.name == "_FRESH_DEADLINES" for a in m.names) for b in node.body for m in ast.walk(b)):
            n += 1
    return n


def test_B10_source_change_is_exactly_the_removed_gate_and_other_protected_files_unchanged():
    """E7 + 02 s.6. PASS iff: (1) the six other protected evaluators have the frozen git blob ids on this subject; (2) predecessor: the gate
    ``if binding is not None:`` around the _FRESH_DEADLINES block exists once; candidate: it exists zero times AND ast.dump(predecessor with the gate
    unwrapped) == ast.dump(candidate) for the WHOLE module (so nothing but the gate and comments changed); (3) candidate vs predecessor text diff has
    exactly one hunk (needs F3B_PRED_SRC; absent => BLOCKED for the candidate)."""
    s = subject()
    for name, blob in PROTECTED_BLOBS.items():
        got = _blob_id((s.src / "agent_control_plane" / name).read_bytes())
        if got != blob:
            fail("B10 %s blob %s != frozen %s" % (name, got, blob))
    mine = (s.src / "agent_control_plane" / "runtime_authority.py").read_text(encoding="utf-8")
    tree = ast.parse(mine)
    guards = _count_guards(tree)
    if s.role == "predecessor":
        ev("B10", guards=guards)
        if guards != 1:
            fail("B10 predecessor: expected exactly 1 gate, found %d" % guards)
        return
    if guards != 0:
        fail("B10 candidate still has %d gate(s)" % guards)
    pred_src = os.environ.get("F3B_PRED_SRC")
    if not pred_src:
        blocked("B10 candidate needs F3B_PRED_SRC to prove the diff is only the gate")
    old = (Path(pred_src) / "agent_control_plane" / "runtime_authority.py").read_text(encoding="utf-8")
    if hashlib.sha256(old.encode()).hexdigest() != PRED_SHA:
        blocked("B10 F3B_PRED_SRC is not the frozen predecessor")
    same = ast.dump(_ast_unwrap_guard(ast.parse(old))) == ast.dump(tree)
    hunks = sum(1 for l in difflib.unified_diff(old.splitlines(), mine.splitlines(), n=0, lineterm="") if l.startswith("@@"))
    ev("B10", ast_equal_after_unwrapping_gate=same, hunks=hunks)
    if not same:
        fail("B10 candidate AST differs from predecessor-with-gate-unwrapped: the change is more than the removed gate")
    if hunks != 1:
        fail("B10 expected one text hunk, found %d" % hunks)


# ================================================================================================ B11 .. B21
def test_B11_original_defect_reproduced_at_predecessor():
    """E1 (03 F3-B 1). Exact frozen fixture: anchor_deadline_to_inputs=True, no PolicyBinding, class bound 30 s, purpose observation accepted at age 30 s,
    29 s stall. EXPECTED-TO-DISPATCH on the predecessor (age at dispatch 59 s, apply once, one destination effect, opening deadline NOW+30 untouched);
    EXPECTED-REFUSED on main (check_expired_before_dispatch, apply 0, no effect, deadline NOW). Both expectations explicit, neither conditional."""
    s = subject()
    res = expect(s, "B11", dict(kind="live_irr", ceil=30, age=30, stall=29, mode="anchor"),
                 pred=dict(decision="authorized", outcome=D, apply_calls=1, destination_effects=1, deadline_offset_s=30.0, wall_elapsed_s=29.0, refusal_count=0),
                 cand=dict(decision="authorized", outcome=R, error=CODE, apply_calls=0, destination_effects=0, deadline_offset_s=0.0,
                           refusal_reasons=[CODE], attempt_statuses=["failed"]))
    ev("B11_age_at_dispatch", age_at_dispatch_s=30 + res["wall_elapsed_s"], dispatched=res["outcome"] == D)


def test_B12_cached_purpose_same():
    """E1 cached-purpose snapshot (reversible_until class, live purpose store down, cached open snapshot age 30, bound 30, stall 29). PASS iff
    decision authorized with the purpose read_state cached_positive on both; predecessor DISPATCHES (apply 1), candidate REFUSES with the existing
    code (apply 0, offset 0). Also: stall 30 pred D / cand R; stall 31 both R."""
    s = subject()
    expect(s, "B12a", dict(kind="cached_rev", ceil=30, age=30, stall=29, mode="anchor"),
           pred=dict(decision="authorized", outcome=D, apply_calls=1, deadline_offset_s=30.0),
           cand=dict(decision="authorized", outcome=R, error=CODE, apply_calls=0, deadline_offset_s=0.0))
    expect(s, "B12b", dict(kind="cached_rev", ceil=30, age=30, stall=30, mode="anchor"), pred=dict(outcome=D), cand=dict(outcome=R))
    expect(s, "B12c", dict(kind="cached_rev", ceil=30, age=30, stall=31, mode="anchor"), pred=dict(outcome=R), cand=dict(outcome=R))


def test_B13_boundary_exact_remaining_bound_minus1_exact_plus1():
    """E1 strict boundary, injected coupled wall+monotonic clocks, precise seconds. Window = bound - age = 10 s (bound 60, age 50).
    Candidate: stall 9 D, stall 10 D (strict '>' keeps the exact boundary dispatched), stall 11 R; offset 10; live and cached. Predecessor: all of 9, 10
    and 11 DISPATCH (offset 60). Class-deadline boundary unchanged on both: age 0 bound 30: stall 30 D, stall 31 R. Zero window (age == bound): with
    injected clocks stall 0 is DISPATCHED and stall 1 REFUSED on the candidate (strict rule; see open-questions Q2), predecessor dispatches both."""
    s = subject()
    for kind in ("live_irr", "cached_rev"):
        for st, c_out in ((9, D), (10, D), (11, R)):
            expect(s, "B13_%s_rem10_stall%d" % (kind, st), dict(kind=kind, ceil=60, age=50, stall=st, mode="anchor"),
                   pred=dict(outcome=D, deadline_offset_s=60.0), cand=dict(outcome=c_out, deadline_offset_s=10.0))
    for st, o in ((30, D), (31, R)):
        expect(s, "B13_class_stall%d" % st, dict(kind="live_irr", ceil=30, age=0, stall=st, mode="anchor"), pred=dict(outcome=o), cand=dict(outcome=o))
    for st, c_out in ((0, D), (1, R)):
        expect(s, "B13_zero_window_stall%d" % st, dict(kind="live_irr", ceil=30, age=30, stall=st, mode="anchor"),
               pred=dict(outcome=D), cand=dict(outcome=c_out, deadline_offset_s=0.0))


def test_B14_property_new_deadline_le_old_deadline():
    """E4. Deterministic seeded grid (random.Random(0xF3B07), 640 inputs over kinds x ceilings x ages x stalls x modes). PASS iff, over every input
    with an authorized decision: same decision and reasons on both subjects; deadline_new <= deadline_old; candidate dispatched => predecessor
    dispatched (no new permission or grace); candidate apply calls <= predecessor's; at least 1 input strictly tighter (the grid exercises the
    change); >= 500 inputs ran without harness error; candidate matches the independent analytic oracle() on every input. Predecessor run: validates
    the oracle against the OLD behaviour (every input matches oracle(role='predecessor')) and records the dump."""
    s = subject()
    me = make_dump(s)
    ok = [v for k, v in me["results"].items() if k.startswith("g") and "harness_error" not in v["res"]]
    ev("B14_counts", total=len([k for k in me["results"] if k.startswith("g")]), ok=len(ok))
    if len(ok) < 500:
        fail("B14 only %d grid inputs ran without harness error (need >= 500); first errors: %s" % (
            len(ok), [v["res"].get("harness_error") for k, v in me["results"].items() if "harness_error" in v["res"]][:3]))
    errs = []
    for k, v in me["results"].items():
        if k.startswith("g") and "harness_error" not in v["res"]:
            errs += ["%s %s" % (k, e) for e in check_against_oracle(v["spec"], v["res"], s.role)]
    if errs:
        fail("B14 [%s] %d oracle mismatches, first: %s" % (s.role, len(errs), errs[:5]))
    if s.role == "predecessor":
        return
    pred = get_pred_dump(s)
    bad, stats = violations_property(pred, me)
    ev("B14_compare", stats=stats, violations=bad[:20])
    if bad:
        fail("B14 %d violations, first: %s" % (len(bad), bad[:5]))
    if stats["tighter"] < 1 or stats["newly_refused"] < 1:
        fail("B14 grid did not exercise the change: %s" % stats)


def test_B15_flag_false_unchanged():
    """E2. flag False (freshness profile present) and no freshness profile at all, all six input kinds, ages 0/10/20/30, ceilings 30, stalls
    0/9/10/11/29/30/31/45. PASS iff the candidate's decision, outcome, deadline offset, apply count, destination effects AND normalized persisted
    document hash equal the predecessor's on every case (byte-identical), and the independent oracle holds on both subjects (flag False: deadline
    offset == bound, dispatched iff stall <= bound; no profile: always dispatched)."""
    s = subject()
    specs = []
    for mode in ("flag_false", "nofresh"):
        for kind in ALL_KINDS:
            for age in (0, 10, 20, 30):
                for st in (0, 9, 10, 11, 29, 30, 31, 45):
                    specs.append({"id": "f_%s_%s_%d_%d" % (mode, kind, age, st), "kind": kind, "ceil": 30, "age": age, "stall": st, "mode": mode})
    mine = {sp["id"]: {"spec": sp, "res": S_run(s, sp)} for sp in specs}
    errs = []
    for sid, v in mine.items():
        if "harness_error" in v["res"]:
            blocked("B15 harness error %s: %s" % (sid, v["res"]["harness_error"]))
        errs += ["%s %s" % (sid, e) for e in check_against_oracle(v["spec"], v["res"], s.role)]
    ev("B15", n=len(mine), oracle_errors=errs[:10])
    if errs:
        fail("B15 [%s] oracle mismatches: %s" % (s.role, errs[:5]))
    if s.role == "predecessor":
        Path(os.environ.get("F3_EVIDENCE_DIR") or (HERE / "evidence")).mkdir(parents=True, exist_ok=True)
        return
    pred_dump = get_pred_dump(s)
    pred = {sp["id"]: S_run_from_pred(pred_dump, sp) for sp in specs}
    diffs = [sid for sid in mine if {k: v for k, v in mine[sid]["res"].items() if not k.startswith("_")} != pred[sid]]
    ev("B15_compare", diffs=diffs[:20])
    if diffs:
        fail("B15 candidate differs from predecessor with flag False/no profile on %d cases, first %s" % (len(diffs), diffs[:5]))


def S_run_from_pred(pred_dump, spec):
    """Predecessor results for a spec that is not part of the dump grid are produced by a second dump phase: ``extra`` section."""
    extra = pred_dump.get("extra", {})
    if spec["id"] in extra:
        return extra[spec["id"]]
    blocked("predecessor dump lacks extra result for %s; run `dump` with F3B_EXTRA=1" % spec["id"])


def test_B16_no_policybinding_vs_with_policybinding():
    """E1/E8. Purpose kinds, ceilings 30/60, ages 0/10/20/ceiling, stalls around the window. PASS iff the CANDIDATE gives identical decision, outcome,
    deadline offset and apply count with (anchor_binding) and without (anchor) a PolicyBinding on every case (the purpose anchor no longer depends on
    the binding). PREDECESSOR: the two modes differ on the defect case (age 30, stall 29: no binding D, binding R), and the binding-mode outcomes
    equal the oracle (binding path anchors)."""
    s = subject()
    diffs, oracle_errs = [], []
    for kind in PURPOSE_KINDS:
        for ceil in (30, 60):
            for age in (0, 10, 20, ceil):
                rem = ceil - age
                for st in sorted({0, max(rem - 1, 0), rem, rem + 1, ceil - 1}):
                    a = S_run(s, dict(kind=kind, ceil=ceil, age=age, stall=st, mode="anchor"))
                    b = S_run(s, dict(kind=kind, ceil=ceil, age=age, stall=st, mode="anchor_binding"))
                    for r in (a, b):
                        if "harness_error" in r:
                            blocked("B16 harness error %s" % r["harness_error"])
                    keys = ("decision", "outcome", "deadline_offset_s", "apply_calls")
                    if tuple(a.get(k) for k in keys) != tuple(b.get(k) for k in keys):
                        diffs.append((kind, ceil, age, st, [a.get(k) for k in keys], [b.get(k) for k in keys]))
                    if s.role == "predecessor":
                        e = check_against_oracle(dict(kind=kind, ceil=ceil, age=age, stall=st, mode="anchor_binding"), b, "predecessor")
                        if e:
                            oracle_errs.append((kind, ceil, age, st, e))
    ev("B16", n_diffs=len(diffs), first=diffs[:5], oracle_errors=oracle_errs[:5])
    if s.role == "candidate" and diffs:
        fail("B16 candidate outcome depends on PolicyBinding presence on %d cases, first %s" % (len(diffs), diffs[:3]))
    if s.role == "predecessor" and not diffs:
        fail("B16 predecessor: expected the no-binding and binding outcomes to differ on the defect cases (the defect), found none")
    if s.role == "predecessor" and oracle_errs:
        fail("B16 predecessor binding path disagrees with the oracle: %s" % oracle_errs[:3])


def test_B17_destination_apply_never_called_after_deadline_refusal():
    """E6. For every refused dispatch below (purpose live/cached, grant, identity, mandate, with and without binding) PASS iff: apply_calls == 0,
    destination_effects == 0, one durable refusal whose reason set is exactly [check_expired_before_dispatch], the attempt status is 'failed', and
    a RETRY of the same execute is also not dispatched and does not call apply (retry_apply_calls == 0). Cases whose subject outcome is dispatched
    (the predecessor defect) are listed in evidence but not asserted here (they are B11/B12)."""
    s = subject()
    specs = [dict(kind=k, ceil=30, age=a, stall=st, mode=m) for k, a, st, m in [
        ("live_irr", 30, 29, "anchor"), ("live_rev", 20, 11, "anchor"), ("cached_rev", 30, 29, "anchor"), ("cached_rev", 20, 11, "anchor_binding"),
        ("grant", 20, 11, "anchor"), ("identity", 20, 11, "anchor"), ("mandate", 20, 11, "anchor"), ("live_irr", 0, 31, "anchor"),
        ("live_irr", 30, 29, "anchor_binding"), ("live_irr", 0, 31, "flag_false")]]
    n_checked = 0
    for sp in specs:
        res = S_run(s, dict(sp, retry=True))
        ev("B17", spec=sp, result={k: v for k, v in res.items() if not k.startswith("_")})
        if "harness_error" in res:
            blocked("B17 harness error %s" % res["harness_error"])
        if res.get("outcome") != R:
            continue
        n_checked += 1
        errs = []
        if res["apply_calls"] != 0 or res["destination_effects"] != 0:
            errs.append("apply/effects after refusal: %s/%s" % (res["apply_calls"], res["destination_effects"]))
        if res["refusal_reasons"] != [CODE]:
            errs.append("refusal reasons %r" % res["refusal_reasons"])
        if res["refusal_count"] < 1 or "failed" not in res["attempt_statuses"]:
            errs.append("no durable refusal / failed attempt: %s" % res)
        if res.get("retry") == "dispatched" or res.get("retry_apply_calls", 0) != 0:
            errs.append("retry dispatched or called apply: %s" % res.get("retry"))
        if errs:
            fail("B17 [%s] %s :: %s" % (s.role, json.dumps(sp, sort_keys=True), "; ".join(errs)))
    if n_checked < (5 if s.role == "predecessor" else 8):
        fail("B17 only %d refused cases were observed (candidate must refuse >= 8 of 10, predecessor >= 5)" % n_checked)


def test_B18_no_new_reason_code_no_schema_change():
    """E5. PASS iff the candidate equals the predecessor on: (a) the set of string literals of runtime_authority.py (AST constants, no new
    reason code); (b) sha256 of every file under schemas/; (c) approval_commitment, catalogue_digest and profile dump sha256 for five profile
    variants (default, freshness, anchored, anchored+extension, with PolicyBinding); (d) the union of reason codes (decision + refusal) over the
    640-input grid; (e) persisted-document key paths: the refusal caused by the change (age 30/stall 29) has EXACTLY the key paths of the
    pre-existing class-deadline refusal, and both equal the predecessor's key paths of the class-deadline refusal. Predecessor run: asserts the
    dump contains all of this and that the changed-case document has no refusal (it dispatched)."""
    s = subject()
    me = make_dump(s)
    reasons = set()
    for v in me["results"].values():
        reasons |= set(v["res"].get("decision_reasons") or []) | set(v["res"].get("refusal_reasons") or [])
    ev("B18", reasons=sorted(reasons), schemas=len(me["static"]["schemas_sha256"]))
    cd = me["results"]["refusal_class_deadline"]["res"]
    ch = me["results"]["refusal_changed_case"]["res"]
    if cd.get("outcome") != R or not cd.get("_doc_key_paths"):
        blocked("B18 class-deadline refusal fixture did not refuse/dump [%s]: %s" % (s.role, {k: v for k, v in cd.items() if not k.startswith("_")}))
    if s.role == "predecessor":
        if ch.get("outcome") != D:
            fail("B18 predecessor: the defect case was expected to dispatch, got %r" % ch.get("outcome"))
        return
    pred = get_pred_dump(s)
    errs = []
    if me["static"]["string_constants"] != pred["static"]["string_constants"]:
        errs.append("string literals differ: +%s -%s" % (sorted(set(me["static"]["string_constants"]) - set(pred["static"]["string_constants"]))[:5],
                                                         sorted(set(pred["static"]["string_constants"]) - set(me["static"]["string_constants"]))[:5]))
    if me["static"]["schemas_sha256"] != pred["static"]["schemas_sha256"]:
        errs.append("schemas/ differ")
    if me["static"]["commitments"] != pred["static"]["commitments"]:
        errs.append("commitments/catalogue/profile dump differ: %s" % [k for k in me["static"]["commitments"] if me["static"]["commitments"][k] != pred["static"]["commitments"].get(k)])
    pr = set()
    for v in pred["results"].values():
        pr |= set(v["res"].get("decision_reasons") or []) | set(v["res"].get("refusal_reasons") or [])
    if reasons != pr:
        errs.append("reason code union differs: +%s -%s" % (sorted(reasons - pr), sorted(pr - reasons)))
    if ch.get("outcome") != R:
        errs.append("changed case did not refuse")
    if ch.get("_doc_key_paths") != cd.get("_doc_key_paths"):
        errs.append("changed-refusal key paths differ from the class-deadline refusal")
    if cd.get("_doc_key_paths") != pred["results"]["refusal_class_deadline"]["res"].get("_doc_key_paths"):
        errs.append("class-deadline refusal key paths differ from predecessor")
    if errs:
        fail("B18 " + "; ".join(errs))


def test_B19_clock_stepped_back_and_monotonic_guards():
    """E5 guards (BD:1423-1431, untouched). Grant-anchored window 10 (age 20 of 30), injected clocks:
    (a) wall stepped back 100 s and 11 s of monotonic time: REFUSED on both (mono allowance 10 exceeded);
    (b) wall stepped back 30 s (beyond the constructor tolerance 5 s), mono unchanged: REFUSED on both (wall earlier than the recorded opening);
    (c) wall stepped back 3 s (inside the tolerance): DISPATCHED on both.
    Purpose-anchored (live, age 20 of 30, window 10): (d) monotonic-only 11 s: predecessor DISPATCHES (allowance 30), candidate REFUSES (allowance
    10); (e) monotonic-only 10 s: DISPATCHED on both (strict '>'); (f) wall-only 11 s: predecessor D, candidate R."""
    s = subject()
    g = dict(kind="grant", ceil=30, age=20, mode="anchor")
    p = dict(kind="live_irr", ceil=30, age=20, mode="anchor")
    expect(s, "B19a", dict(g, steps=[("wall_back", 100), ("mono_only", 11)]), pred=dict(outcome=R, error=CODE), cand=dict(outcome=R, error=CODE))
    expect(s, "B19b", dict(g, steps=[("wall_back", 30)]), pred=dict(outcome=R, error=CODE), cand=dict(outcome=R, error=CODE))
    expect(s, "B19c", dict(g, steps=[("wall_back", 3)]), pred=dict(outcome=D), cand=dict(outcome=D))
    expect(s, "B19d", dict(p, steps=[("mono_only", 11)]), pred=dict(outcome=D), cand=dict(outcome=R, error=CODE, apply_calls=0))
    expect(s, "B19e", dict(p, steps=[("mono_only", 10)]), pred=dict(outcome=D), cand=dict(outcome=D))
    expect(s, "B19f", dict(p, steps=[("wall_only", 11)]), pred=dict(outcome=D), cand=dict(outcome=R, error=CODE, apply_calls=0))


def test_B20_outage_extension_never_raises_narrowed_ceiling_for_every_anchored_input():
    """E3. Class bound 30, signed extension to 90 (host limit 100), flag on, no binding unless stated. For EVERY anchored input:
    cached purpose age 80: accepted at the recorded bound 90, window 10: candidate offset 10 (stall 10 D, 11 R); predecessor offset 60 (the 60 s identity/mandate anchors cap the extended opening deadline of 90; stall 11 D);
    live purpose age 31: HELD both (extension does not raise live acceptance); live age 20: candidate offset 10 (anchor at base 30, NOT 90), stall
    11 R; predecessor offset 60, stall 11 D; identity/mandate age 31: HELD both; age 20: offset 10 and stall 11 R on both (extension never reaches
    them); grant status age 80: authorized on both at the extended bound, offset 10, stall 11 R on both; irreversible class with a reversibility
    profile and extension: grant age 31 HELD on both; extension beyond the host limit: refused at record time on both. The result of a PolicyBinding
    host with an extension above its ceiling (cached age 80) is RECORDED as an INFO observation and must be identical on both subjects; whether an
    extension may exceed a narrowed ceiling is open-questions Q3 (a proposal, not asserted)."""
    s = subject()
    ext = dict(ext_to=90)
    expect(s, "B20_cached_ok", dict(kind="cached_rev", ceil=30, age=80, stall=10, mode="anchor", **ext), pred=dict(outcome=D, deadline_offset_s=60.0),
           cand=dict(outcome=D, deadline_offset_s=10.0))
    expect(s, "B20_cached_over", dict(kind="cached_rev", ceil=30, age=80, stall=11, mode="anchor", **ext), pred=dict(outcome=D, deadline_offset_s=60.0),
           cand=dict(outcome=R, deadline_offset_s=10.0, apply_calls=0))
    expect(s, "B20_live_31", dict(kind="live_rev", ceil=30, age=31, stall=0, mode="anchor", **ext), pred=dict(decision="hold"), cand=dict(decision="hold"))
    expect(s, "B20_live_20_over", dict(kind="live_rev", ceil=30, age=20, stall=11, mode="anchor", **ext), pred=dict(outcome=D, deadline_offset_s=60.0),
           cand=dict(outcome=R, deadline_offset_s=10.0))
    for kind in ("identity", "mandate"):
        expect(s, "B20_%s_31" % kind, dict(kind=kind, ceil=30, age=31, stall=0, mode="anchor", **ext), pred=dict(decision="hold"), cand=dict(decision="hold"))
        expect(s, "B20_%s_20_over" % kind, dict(kind=kind, ceil=30, age=20, stall=11, mode="anchor", **ext),
               pred=dict(outcome=R, deadline_offset_s=10.0), cand=dict(outcome=R, deadline_offset_s=10.0))
    expect(s, "B20_grant_80_ok", dict(kind="grant", ceil=30, age=80, stall=10, mode="anchor", **ext), pred=dict(outcome=D, deadline_offset_s=10.0),
           cand=dict(outcome=D, deadline_offset_s=10.0))
    expect(s, "B20_grant_80_over", dict(kind="grant", ceil=30, age=80, stall=11, mode="anchor", **ext), pred=dict(outcome=R, deadline_offset_s=10.0),
           cand=dict(outcome=R, deadline_offset_s=10.0))
    expect(s, "B20_irreversible_profile", dict(kind="grant_revprof_irr", ceil=30, age=31, stall=0, mode="anchor", **ext), pred=dict(decision="hold"),
           cand=dict(decision="hold"))
    over = S_run(s, dict(kind="cached_rev", ceil=30, age=5, stall=0, mode="anchor", ext_to=1000, ext_limit=100))
    ev("B20_over_limit", result=over)
    if "age_extension_exceeds_limit" not in (over.get("extension_refused") or []):
        fail("B20 extension beyond the host limit was not refused at record time: %s" % over)
    info = S_run(s, dict(kind="cached_rev", ceil=30, age=80, stall=11, mode="anchor_binding", **ext))
    ev("B20_INFO_extension_above_binding_ceiling", result={k: v for k, v in info.items() if not k.startswith("_")},
       note="observation only: a PolicyBinding age ceiling of 30 coexists with an extension to 90; identical on both subjects is asserted by the B14/B16 comparison, not here")
    if "harness_error" in info:
        blocked("B20 INFO case harness error: %s" % info["harness_error"])


def test_B21_grant_status_identity_mandate_anchoring_unchanged():
    """E2. Grant status, identity, mandate over ceilings 30, ages 0/10/20/30, stalls {0, rem-1, rem, rem+1, 31}, modes anchor and flag_false.
    PASS iff candidate == predecessor exactly (decision, outcome, deadline offset, apply count, normalized document hash) on every case and both
    equal the independent oracle (strict boundary at rem)."""
    s = subject()
    specs = []
    for kind in ("grant", "identity", "mandate"):
        for mode in ("anchor", "flag_false"):
            for age in (0, 10, 20, 30):
                rem = 30 - age
                for st in sorted({0, max(rem - 1, 0), rem, rem + 1, 31}):
                    specs.append({"id": "c_%s_%s_%d_%d" % (kind, mode, age, st), "kind": kind, "ceil": 30, "age": age, "stall": st, "mode": mode})
    mine = {sp["id"]: S_run(s, sp) for sp in specs}
    errs = []
    for sp in specs:
        res = mine[sp["id"]]
        if "harness_error" in res:
            blocked("B21 harness error %s" % res["harness_error"])
        errs += ["%s %s" % (sp["id"], e) for e in check_against_oracle(sp, res, s.role)]
    ev("B21", n=len(specs), oracle_errors=errs[:10])
    if errs:
        fail("B21 [%s] oracle mismatches: %s" % (s.role, errs[:5]))
    if s.role == "predecessor":
        return
    pred = get_pred_dump(s).get("extra", {})
    missing = [sp["id"] for sp in specs if sp["id"] not in pred]
    if missing:
        blocked("predecessor dump has no extra results for B21 (%d missing); produce it with F3B_EXTRA=1 dump" % len(missing))
    diffs = [sp["id"] for sp in specs if {k: v for k, v in mine[sp["id"]].items() if not k.startswith("_")} != pred[sp["id"]]]
    if diffs:
        fail("B21 candidate differs from predecessor on %d control cases, first %s" % (len(diffs), diffs[:5]))


def _b22_probe(src, pin):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OCS_REQUIRE_REGISTRY_PIN="1", OCS_REGISTRY_PIN_DIR=str(pin))
    env.pop("F3B_SUBJECT_SRC", None)
    proc = subprocess.run([sys.executable, str(HERE / "b22_probe.py"), str(src)], env=env, capture_output=True, text=True, timeout=600)
    if proc.returncode != 0:
        blocked("B22 probe failed for %s: %s" % (src, proc.stderr[-800:]))
    return json.loads(proc.stdout)


def test_B22_profile_bearing_families_policy_binding_unsupported_unchanged():
    """AMEND-2 (see evidence/runs/B-amendments.md, section sha256 recorded there). 03 F3-B 8. Differential vs baseline b7eb11a (F3B_BASE_SRC, pin F3B_BASE_PIN)
    for three constructors. Per site PASS iff: both trees raise the family's Refused exception class with code policy_binding_unsupported, boundary
    'construction', non_authorizing True, PermissionError subclass; the (class, code, boundary) triple is identical on baseline and subject; nothing is
    returned; control without PolicyBinding raises a different code or constructs (never policy_binding_unsupported) on both trees."""
    s = subject()
    base_src, base_pin = os.environ.get("F3B_BASE_SRC"), os.environ.get("F3B_BASE_PIN")
    if not base_src or not base_pin:
        blocked("B22 needs F3B_BASE_SRC (b7eb11a src) and F3B_BASE_PIN (Registry checkout accepted by the baseline)")
    subj_pin = os.environ.get("OCS_REGISTRY_PIN_DIR")
    if not subj_pin:
        blocked("B22 needs OCS_REGISTRY_PIN_DIR for the subject")
    base = _b22_probe(base_src, base_pin)
    mine = _b22_probe(s.src, subj_pin)
    ev("B22", baseline=base, subject=mine, base_src=base_src, base_pin=base_pin, subject_pin=subj_pin)
    if "setup_error" in base or "setup_error" in mine:
        blocked("B22 fixture setup error: baseline=%s subject=%s" % (base.get("setup_error"), mine.get("setup_error")))
    errs = []
    for site in ("S1", "S2", "S3"):
        triples = []
        for name, tree in (("baseline", base), ("subject", mine)):
            w, c = tree.get(site + "|with_binding"), tree.get(site + "|without_binding")
            if not w or "raised" not in w:
                errs.append("%s %s: with binding did not raise: %s" % (site, name, w)); continue
            if w["code"] != "policy_binding_unsupported" or w["boundary"] != "construction" or w["non_authorizing"] is not True or not w["is_permission_error"]:
                errs.append("%s %s: wrong refusal %s" % (site, name, w))
            if not c or c.get("code") == "policy_binding_unsupported":
                errs.append("%s %s: control without binding gave %s" % (site, name, c))
            triples.append((w["raised"], w["code"], w["boundary"]))
        if len(triples) == 2 and triples[0] != triples[1]:
            errs.append("%s triple differs: baseline %s subject %s" % (site, triples[0], triples[1]))
    if errs:
        fail("B22 " + "; ".join(errs))


# ================================================================================================ CLI: dump / compare
def _extra_specs():
    specs = []
    for mode in ("flag_false", "nofresh"):
        for kind in ALL_KINDS:
            for age in (0, 10, 20, 30):
                for st in (0, 9, 10, 11, 29, 30, 31, 45):
                    specs.append({"id": "f_%s_%s_%d_%d" % (mode, kind, age, st), "kind": kind, "ceil": 30, "age": age, "stall": st, "mode": mode})
    for kind in ("grant", "identity", "mandate"):
        for mode in ("anchor", "flag_false"):
            for age in (0, 10, 20, 30):
                rem = 30 - age
                for st in sorted({0, max(rem - 1, 0), rem, rem + 1, 31}):
                    specs.append({"id": "c_%s_%s_%d_%d" % (kind, mode, age, st), "kind": kind, "ceil": 30, "age": age, "stall": st, "mode": mode})
    return specs


def _cli(argv):
    if len(argv) >= 3 and argv[1] == "dump":
        S0 = subject_cli()
        dump = make_dump(S0)
        dump["extra"] = {sp["id"]: {k: v for k, v in S_run(S0, sp).items() if not k.startswith("_")} for sp in _extra_specs()}
        # make_dump keeps the _doc_key_paths for the three refusal fixtures; strip nothing else
        Path(argv[2]).write_text(json.dumps(dump, sort_keys=True, default=str), encoding="utf-8")
        print("dumped", argv[2], "role", S0.role, "grid", len([k for k in dump["results"] if k.startswith("g")]))
        return 0
    if len(argv) >= 4 and argv[1] == "compare":
        pred = json.loads(Path(argv[2]).read_text(encoding="utf-8"))
        cand = json.loads(Path(argv[3]).read_text(encoding="utf-8"))
        if pred["role"] != "predecessor" or cand["role"] != "candidate":
            print("BLOCKED: dumps are not (predecessor, candidate)")
            return 2
        bad, stats = violations_property(pred, cand)
        print(json.dumps(stats), "violations:", len(bad))
        for b in bad[:50]:
            print("FAIL:", b)
        return 1 if bad or stats["tighter"] < 1 else 0
    print(__doc__)
    return 2


def subject_cli():
    _load()
    if _S is None:
        print("BLOCKED:", _S_ERR)
        raise SystemExit(2)
    return _S


if __name__ == "__main__":
    raise SystemExit(_cli(sys.argv))

# Worker A: oracle notes for F3-A (D-06 persisted effective-configuration binding)

Written BEFORE reading the implementation (oracle docs read first). Registry docs at main 2815643, dir `docs/family-migration/final-three/`.
Cited as `03:<line>` = 03-f3-qualification-expectations (F3-A block is lines 19-31), `02:<line>` = 02-architect-authorization-and-contract-freeze (section 4 = lines 44-56, section 5 = lines 58-62, section 2 sub-decisions = lines 22-38).

## What the contract says, in my words

### Frozen binding (02 s4, 02:44-56)
* Carriage C2: one named member `runtime_authority["effective_configuration"] = {version: "effective-configuration-binding/0.1", digest: "sha256:<64 hex>", members: {...}}` inside the already-persisted OPAQUE dict `binding.runtime_authority`. No typed field, no schema file change, no `approval_commitment`/`catalogue_digest` change, no protected-evaluator edit (02:26, 02:46).
* digest = existing canonical `commitment()` (sorted-key canonical JSON) over domain `cognous.control-plane.effective-configuration-binding`, `version`, then the members (02:48). Members (02:48): `scope` {consumer, tenant, action, institution, authority_domain}; `host_profile_digest`; `effective_profile_digest` (= `catalogue_digest` for profile-bearing workflows, else null); `f4_scalars` {status_max_age_seconds, approval_max_age_seconds} (LIVE values even when F4 family is not declared); `other_scalars` {clock_tolerance_seconds (constructor), identity_max_age_seconds, mandate_max_age_seconds}; `observation_policy` {max_age_seconds, clock_tolerance_seconds} effective values OR explicit JSON null; `families` = declared families in fixed order each {slot, family_id, contract_version, family_schema_revision, effective_policy_digest}; an undeclared family is ABSENT (declared set is part of identity).
* Excluded on purpose: `evaluated_at`, `selection_id`, `selection_epoch` (02:28).
* Validation before hashing: exact `int` (never bool), 0..2147483647; exact `str`; digests `sha256:` + 64 lowercase hex, not all-zero; otherwise the workflow refuses (02:48).
* Rules (02:50-56), all fail closed:
  1. Authorized governed decision mints the member; a hold persists no binding (02:50).
  2. Execute AND pin-export claim recompute the live member and compare. Absent member -> legacy classification only. Present but invalid / unknown `version` / `digest` != recomputation of own `members` / unequal to live -> refuse `authorization_binding_changed` (02:51).
  3. Refusal-only equality check; never an approval input; never widens a bound; grants no authority (02:52).
  4. Restart: nothing in memory (02:53). 5. No "re-bind"; changed config needs a new decision (02:54). 6. `approval_commitment`, `catalogue_digest`, `RuntimeAuthorityProfile`, published schemas, reason vocabulary unchanged; existing approvals stay valid (02:55).
* Always on for governed lifecycle decisions: no off switch (02:29). Reuse registered `authorization_binding_changed` as a durable `EffectTimeRefusal`; no new durable code (02:30).

### legacy_cutoff (02 s5, 02:58-62)
* Host-supplied explicit finite integer, default 0 (= no legacy decision accepted), "the number of rows in the append-only `decisions` list at activation". A decision WITHOUT the member and index BELOW the cutoff executes under exactly the previous semantics (member omitted from the live side before the equality; nothing else ignored), reported `legacy`. Without a cutoff, at/past it, or when the member is stripped: refuse (02:60).
* NO durable provenance (02:62): host config, unsigned local JSON store, no signed floor, no ratchet. Stated limitation retained as a hold: guards drift / restart-rebuild mix-ups / partial upgrades / buggy writers; NOT a defence against a store rewriter; NO anti-rollback (rolling back to a config whose digest equals an older persisted binding revives that old decision, "now visibly"). Anti-rollback and signed store are a separate held item; no guarantee claimed.

### F3-A qualification expectations (03:19-31); the qualifier may add, never drop
1. (03:23) Same config across restart and separate process: accepted. Every member perturbed independently (each F4 scalar, each other scalar incl. constructor tolerance, ObservationPolicy max age, ObservationPolicy tolerance, ObservationPolicy present vs explicitly absent, host profile digest, effective profile digest, scope field, family set, each family's contract version, schema revision, effective-policy digest) changes the digest and makes execute AND pin-export refuse with `authorization_binding_changed` and a durable `EffectTimeRefusal`; destination untouched.
2. (03:24) Unknown binding version, malformed member, `digest` != recomputation of `members`, wrong types (bool, float, str number, negative, huge): refuse.
3. (03:25) Missing member: refuse unless the explicit `legacy_cutoff` rule applies; default 0; stripped member on a record at/past the cutoff refuses; no wildcard/accept-all value; negative, non-int, bool, huge cutoff handled by an explicit documented rule.
4. (03:26) Legacy compat: a store generated by the UNCHANGED prior binary (frozen fixture) executes below cutoff under previous semantics and is reported `legacy`; same record past cutoff refuses; legacy approvals still validate (`approval_commitment` byte-identical).
5. (03:27) `catalogue_digest`, `approval_commitment`, `RuntimeAuthorityProfile` dump, published JSON schemas, reason vocabulary, `EffectivePolicySnapshot.identity_digest`, Registry r08-v1..v7 identities byte-identical to pre-change baseline; a legacy-binary-on-new-record test shows the old reader fails CLOSED.
6. (03:28) Binding confers no authority: cannot turn a hold into an authorization, cannot widen a bound, never read by an approval, never removes a refusal produced by another check.
7. (03:29) Recovery/fault: crash points around `append_decision`; a hold persists no binding; an attempt already `failed` still blocks retry.
8. (03:30) Negative controls constructed independently: member-order shuffle, duplicate keys, extra unknown members inside `effective_configuration`, replayed member copied from another decision or scope (scope member must refuse), downgrade by deleting the member.
9. (03:31) Stated limits present and honest: unsigned store, no anti-rollback, host-supplied cutoff, mixed-fleet legacy writers. The qualifier FAILS any claim of anti-rollback protection.

### Evidence/independence bindings (03:3-17, 03:48-50)
CA04: define and execute own oracle; do not fit oracle to implementation; builder tests/mutations/CI are developer evidence only. CA06: preserve adverse results with original output. CA07: exact frozen heads only; no pass transfer across revisions. Absence of a qualifier is "pending", not pass.

## Points where the oracle is silent or tension exists (see open-questions.md)
* 03:23 demands a durable `EffectTimeRefusal` for pin-export; the pin-export path is documented read-only (`authorization_pin_export.py:3-15`, "No decision, grant, approval or policy record is created or changed") and returns state `unknown`. 02:51 only says "refuse `authorization_binding_changed`".
* Host change fully masked by stricter Registry value: not addressed by 02/03.
* "Every member perturbed independently ... execute AND pin-export" vs. what a profile-bearing/pin-capable workflow can even declare (profile + policy_binding forces F4-only composition).
* Whether the A1..A10 labels of the assignment correspond 1:1 with 03 items (assumed mapping is in the harness header).

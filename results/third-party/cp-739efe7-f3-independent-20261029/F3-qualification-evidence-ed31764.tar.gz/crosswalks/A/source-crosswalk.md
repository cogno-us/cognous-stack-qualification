# Worker A: source crosswalk for F3-A (static inspection only; nothing was executed)

Subject: Control Plane main 739efe7d8f16a0cee1efc7dd3a978d5d4d85fe69 (`run/cp`, detached). Pre-change baseline used for diffs: `b7eb11a` (`git diff b7eb11a 739efe7`, read-only).
Paths in `src/agent_control_plane/` unless stated. `LC` = registry_governed_lifecycle.py, `ECB` = effective_configuration_binding.py, `B` = bounded.py, `PE` = authorization_pin_export.py, `LAE` = local_authority_effect.py, `GP` = registry_governed_policy.py.
Everything below is READ from source; "enforced" means a line that does it, not that it was run. All runtime behaviour is UNVERIFIED until the lead freezes the protocol and the harness runs.

## 0. The enforcement spine (one mechanism covers three paths)
* Member construction: `LC:199-218` (`_gl_common_members`, `_gl_build_members`) -> `ECB:158-166` (`build_members`, validated by `ECB:78-105` `members_defect`) -> `ECB:113-119` (`mint`; digest `ECB:108-110` over `{"domain","version",**members}` via `bounded.commitment`).
* Mint on decision: `LC:273-274` (`stage == "decision" and target is None` -> `_gl_with_member`, `LC:287-291`). Only reached when base `_resolve` returned no reasons and a binding (`LC:267-268`), so a hold persists nothing (`B:1656` `binding=binding if not reasons else None`, `B:1659` `append_decision`).
* Check: `LC:275` -> `configuration_binding_status` `LC:252-261` -> `ECB:193-209` `classify` (`bound`/`mismatch`/`invalid`/`version-unsupported`/`legacy`/`unbound-after-cutoff`); record validity in `ECB:169-185` `record_defect` (version closed set, exact key set `RECORD_FIELDS`, digest regex, `members_defect`, `digest_of(...) == digest`).
* Refusal: `LC:278-285`. LEGACY -> returns the UNSTAMPED binding (`LC:279-280`); otherwise stamps the live member and, if the status is not accepted AND `stamped.runtime_authority == persisted_ra` (equality conflation guard, `LC:283`), adds `authorization_binding_changed`. In the ordinary mismatch case the refusal comes from the base inequality, not from the reason added here.
* Three consumers of `_resolve`: execute `B:1685`/`B:1690-1711` (refusal row `B:1694-1710`: `EffectTimeRefusal`, fallback reason `["authorization_binding_changed"]` at `B:1693`, `PermissionError` `B:1711`); pin-export `PE:170-189`; claim `LAE:443-458`.
* Governed entry guards (before `_resolve`): `LC:326-337` (`decide`/`execute` call `_gl_revalidate` -> `_gl_reverify` `LC:303-316` -> held-state `LC:227-232`, `GP:488-509`). These are NON-durable adapter refusals (`RegistrySelectionRefused`), not `authorization_binding_changed`.
* Files byte-unchanged `b7eb11a..739efe7` (git diff empty): `bounded.py`, `local_authority_effect.py`, `authorization_pin_export.py`, `reason_vocabulary.py`, `models.py`, `schemas/*`. Changed: `effective_configuration_binding.py` (new), `registry_governed_lifecycle.py`, `registry_governed_policy.py`, `registry_f4_age_governance.py`, `registry_f5_class_age_governance.py`, `registry_f5_class_unreadable_governance.py`, `registry_effective_policy.py` (+3 family rows, +3 schema revisions), `registry_final3_governance.py` (new), `runtime_authority.py` (D-07, out of F3-A). (Supports 03 item 5 for the vocabulary/schemas/bounded; `approval_commitment` is in runtime_authority.py which changed ONLY in the D-07 hunk viewed at `git diff b7eb11a 739efe7 -- runtime_authority.py`: purpose-anchor block; no `approval_commitment` hunk seen. UNVERIFIED by execution.)

## 1. Matrix: 03 F3-A expectations 1-9 x path
Legend: E = enforced at cited line; N = NOT enforced / not found; ? = ambiguous.

| 03 item | execute | pin-export | claim |
|---|---|---|---|
| 1a same config accepted (restart/process) | E `LC:278-285` equality `B:1690` | E same, `PE:181` | E same, `LAE:455` (profile workflows) |
| 1b perturbed member -> digest differs, refuse `authorization_binding_changed` | E: reason `B:1693`, durable row `B:1694` | PARTIAL: refused (state `unknown`, `PE:181-188`) but NO `EffectTimeRefusal` row (PE writes none; only `B:1441`/`B:1694` append refusals) and the reason text is `"binding changed"` (`PE:187`, `reasons` is empty) unless the conflation guard fired (`LC:283`). Contract 03:23 literal expectation not met by construction. | PARTIAL: `PermissionError("authorization-critical inputs changed before claim issuance")` `LAE:458`, no refusal row, reason string not `authorization_binding_changed` |
| 1c destination untouched | E: refusal raises `B:1711` before attempt creation (`B:1764-1780`) and before `apply` `B:1794` | E: pin export never touches the destination | E (no destination) |
| 2 unknown version / malformed / digest != recomputation / bad types | E `ECB:169-185`, `ECB:74-105` (`type(v) is int`, bool excluded, `0..SCALAR_MAX`, exact key sets) -> INVALID / VERSION_UNSUPPORTED `ECB:205-208` | E same classifier via `_resolve` | E for profile workflows; GAP candidate for no-profile workflows (see F-2) |
| 3 missing member -> legacy rule only | E `ECB:200-202` (`0 <= index < cutoff <= decision_count`, cutoff exact int `ECB:188-190`) | E same | E for profile workflows (F-2 for no-profile) |
| 3b cutoff domain | E at construction `LC:126-129` (called first thing in `GP:308`, F4 `registry_f4_age_governance.py:107`, class age `registry_f5_class_age_governance.py:197`, unreadable `registry_f5_class_unreadable_governance.py:247`); STRICTER than contract: also refuses `cutoff > len(decisions)` `LC:241-247` and unreadable store | n/a | n/a |
| 4 legacy store, previous semantics, `legacy` | E `LC:279-280` (unstamped binding equals persisted) | E same | E for profile workflows |
| 4b past cutoff / stripped refuses | E `ECB:202` UNBOUND_AFTER_CUTOFF then `LC:281-285` | E | E |
| 5 compat (catalogue_digest, approval_commitment, profile dump, schemas, vocabulary, identity_digest, r08-v1..v7) | E by non-modification: file list above; the member is added to the opaque dict only `LC:288-291` | same | same |
| 5b legacy binary on new record fails closed | By construction: legacy `B:1690` compares the whole binding; a one-key-larger `runtime_authority` is unequal (needs execution of the pre-change binary to verify: UNVERIFIED) | same | same |
| 6 confers no authority | E: `_resolve` returns early on any base reason or `binding is None` `LC:267-268`; member only added after authorization; only `ACCEPTED` statuses pass `LC:281-285`; no approval reads it (`runtime_authority.py` `approval_commitment` has no `effective_configuration` reference: grep for the KEY finds it only in ECB/LC/GP/docs) | E | E |
| 7 hold persists no binding | E `B:1656` and `LC:267-268` | n/a | n/a |
| 7b failed attempt blocks retry | E (not D-06 code): `B:1764-1767` prior attempts raise; config refusal happens BEFORE attempt creation so it creates no attempt (`B:1690-1711`) | n/a | n/a |
| 7c crash around `append_decision` | Atomic replace of the whole document `B:1010-1030` (tmp + fsync + `os.replace` + dir fsync) so a crash yields either no decision or a complete decision incl. member; no D-06 code involved | same | same |
| 8a member-order shuffle | E dict equality is order-insensitive and the digest is sorted-key canonical `B:75-88` (families LIST order is significant and part of identity) | E | E |
| 8b duplicate keys in persisted store | E at store load `strict_loads` `B:599` (`strict_json.py` duplicate member name refused) -> exception before classification; NO refusal row possible (store unreadable); exception type is a plain `ValueError`-class, not a governed refusal | same (via `records.decision`) | same |
| 8c extra unknown member | E `ECB:75` (`set(d) == set(fields)`) at record, members and every sub-dict | E | E |
| 8d replayed member from another scope | E: `scope` is a member (`ECB:48`, `LC:202`) so a self-consistent foreign member is `mismatch` | E | E |
| 8e downgrade by deleting member | E at/past cutoff or cutoff 0 `ECB:200-202`; BELOW the cutoff a stripped member is indistinguishable from a legacy record and is ACCEPTED (documented limit, effective-configuration-binding.md:154) | same | same |
| 9 stated limits | present in `docs/effective-configuration-binding.md:150-159` and `ECB:23-24`; mixed-fleet at :103,:156; host cutoff :154; no anti-rollback :153; unsigned :152 | n/a | n/a |

## 2. Coverage items A01-A10 (assumed mapping; see open-questions.md Q1) with enforcement cites
| id | content | cite |
|---|---|---|
| A01 | same config accepted across restart | `LC:278-285`, classification `ECB:209` |
| A02 | each member perturbed -> execute refuses durable | `B:1690-1711` |
| A03 | unknown version / malformed / digest mismatch -> refuse | `ECB:169-185` |
| A04 | missing member refuses at default cutoff | `ECB:200-202` |
| A05 | cutoff rules (bool, negative, str, float, huge, > count) | `ECB:188-190`, `LC:126-129`, `LC:241-247` |
| A06 | frozen legacy store executes below cutoff as `legacy`, refuses past | `LC:279-280`, `ECB:201` |
| A07 | legacy binary on new record fails closed | `B:1690` (unchanged) |
| A08 | hold persists no binding; hold stays hold | `B:1656`, `LC:267-268` |
| A09 | compat byte-identical surfaces | file list in section 0 |
| A10 | pin-export accepts same config (positive control) and returns `active` | `PE:191-235` |

## 3. Findings (suspected gaps; each needs execution to confirm)
* F-1 (potential contract divergence; MEDIUM): 03:23 says execute AND pin-export refuse with `authorization_binding_changed` AND a durable `EffectTimeRefusal`. `authorization_pin_export.py` creates no refusal row (module docstring `PE:14-15` says only a resolution check is journaled), returns `{"state":"unknown", reason:"authority not supported but not positively terminal: binding changed"}` (`PE:186-188`); the token `authorization_binding_changed` appears in `reasons` only if the `LC:283` conflation branch fired. The builder's own doc is inconsistent: `effective-configuration-binding.md:101` ("durable EffectTimeRefusal; execute and pin-export both") vs `:113` ("On the pin-export path the result is not active and carries no payload"). Whether this is a violation depends on reading 02:51 (only "refuse `authorization_binding_changed`") vs 03:23. Safe direction: the export is refused (never `active`).
* F-2 (possible gap; LOW-MEDIUM; UNVERIFIED): a governed workflow WITHOUT a runtime-authority profile (F4 dedicated, `registry_f4_age_governance.py:110-111` forbids a profile) reaches `_resolve` from `materialize_local_execution_claim` with NO `stage`/`decision` kwargs (`LAE:442-447`, `journal` False). `_EXEC_DECISION` is None there, so `LC:273` takes the MINT branch (`target is None`, `stage` defaults to `"decision"`) and returns a binding stamped with the LIVE member; the claim then does a plain equality `LAE:455`. Consequences: (a) a persisted member whose numbers are numerically equal but wrongly typed (30.0 for 30, true for 1) compares EQUAL and the claim is issued, contradicting 02:51/03:24 (wrong types refuse) on the claim route; (b) a legitimately `legacy` decision below the cutoff is over-refused on the claim route. The builder doc admits this edge unverified (`effective-configuration-binding.md:155`). Harness A17 drives it (`path=claim`).
* F-3 (LOW; UNVERIFIED): if `decide()` is invoked inside an `execute()` context (re-entrant callback from destination/observer on the same workflow, same context), `_EXEC_DECISION` is set so `LC:269` makes `target` the executing decision and `LC:273` does not mint; for a LEGACY classification `LC:279-280` returns the unstamped binding, so the new decision would carry NO member. Exotic; recorded for completeness; not harness-driven.
* F-4 (documented-limit gap): "a host change fully masked by a stricter Registry value is not refused" (Registry PR #79 handoff s5 only; NOT in `docs/effective-configuration-binding.md` s10). Mechanism: `f4_scalars`/`observation_policy` bind EFFECTIVE values (`LC:203-206`), and each family row binds the Registry effective-policy digest (`ECB:154`), so a host scalar edited without changing the min() result is invisible. Host PROFILE edits are not masked (`host_profile_digest` is a member, `GP:482-486`). See classification table.
* F-5 (LOW, in-process only): `_gl_legacy_cutoff` is a plain mutable attribute not covered by the held-state guard `LC:220-232`; a host with in-process access can widen it after construction (the construction checks `LC:241-247` do not re-run). Same trust domain as the host; not an attacker model in 02:62.
* F-6 (stricter than contract, not a violation): construction refuses cutoff > current decision count and an unreadable store `LC:241-247`; all five scalars + ObservationPolicy must be exact ints 0..2147483647 even without F4 (`LC:234-240`, docs s9a); new held-state refusal `scalars_modified` pre-write. These are behaviour tightenings the contract text (02:48 "validated before hashing") covers only partly. Fail-closed direction; flag for lead (Q5).
* F-7 (note for the harness): an in-process perturbation of a live scalar after construction is refused by the held-state guard as `scalars_modified` BEFORE any `_resolve` (`LC:228-232`, `LC:326-332`): non-durable adapter refusal, NOT `authorization_binding_changed`. Perturbations that test the binding must be done by REBUILDING the workflow (restart) with different constructor values, or by rewriting the persisted member. The harness does both.
* F-8 (observation): the commit gate `LC:318-324` re-verifies Registry material only; the persisted member is not re-checked there (it was classified at `_resolve`, once, at execute entry `B:1685`). No window is claimed by the contract; noted.
* F-9 (observation): `FAMILY_TABLE` row/order coverage: `GP:64-65` `FAMILY_NAMES` lists all nine slots incl. `terminal_revocation`; `ECB:141-146` raises `BindingInvalid("family_slot_unknown")` for an unknown bound slot (fail closed, matches doc claim).

## 4. Documented limitations: classification
| limitation | where documented | classification |
|---|---|---|
| Unsigned persistence (store rewriter defeats the binding) | 02:62; `effective-configuration-binding.md:152`; `ECB:23-24`; PE docstring `PE:12` | ACCEPTED BOUNDED LIMITATION (explicitly in the frozen contract). A forged self-consistent member is accepted if it equals the live one: harness records this as an observation, not a failure. |
| No anti-rollback | 02:62; md:153 | ACCEPTED BOUNDED LIMITATION; the oracle (03:31) requires that NO claim of anti-rollback appears: harness A24 scans the CP docs/module docstrings for affirmative claims. |
| `legacy_cutoff` has no durable provenance | 02:62; md:154,:157 | ACCEPTED BOUNDED LIMITATION (cites above). Note the extra construction clamp (F-6) is a mitigation, not provenance. |
| Mixed-fleet legacy writers | md:103,:156 | ACCEPTED BOUNDED LIMITATION for legacy READERS (they accept; cannot be fixed in code); new readers refuse past the cutoff. Not a violation of 03:31 as worded. |
| Host change masked by stricter Registry overlay not refused | ONLY Registry PR #79 handoff s5 (a builder-prepared handoff, not a contract doc); absent from CP `md` s10 | POSSIBLE GAP IN STATED LIMITS rather than a violation: 02:48 binds "live values" of F4 scalars (effective), so the behaviour matches the frozen member set. But 03:23 lists "each F4 scalar" as a perturbation that must refuse, which holds for the effective value only. Lead decides (Q3). Shortfall in documentation: not listed among the "honest limits" in the CP doc. |
| Below-cutoff stripped member = legacy | md:154 | ACCEPTED (inherent in 02:60: "index below the cutoff executes under exactly the previous semantics") |
| Legacy decision keeps the old unbound-config gap | md:159 | ACCEPTED (inherent in 02:60) |
| `_EXEC_DECISION` mint/check split for no-profile workflows | md:155 | The builder calls it open/unverified. POSSIBLE VIOLATION on the claim route (F-2). |

## 5. Things the code does that the contract does not say
* Stricter cutoff clamp (`LC:241-247`); new scalar validation and `scalars_modified` guard (`LC:220-248`) for ALL five scalars + ObservationPolicy even when F4 is undeclared.
* Always-on for the four governed workflows (consistent with 02:29); plain `BoundedAuthorizationWorkflow` mints nothing (02:29 agrees).
* `classify` treats an unknown index (duplicate/absent decision id) as never-legacy `LC:260`, `ECB:201` (stricter).
* `EffectPolicySnapshot.identity_digest` unchanged: `registry_effective_policy.py` diff only adds table rows; its digest function was not changed (UNVERIFIED by execution; harness cannot compare to a pre-change digest without the baseline checkout).

## 6. PROPOSALS (not obligations)
* PROPOSAL P-1: pin-export/claim could journal a durable refusal evidence row; today they cannot without touching `bounded.py`/`PE`. Only if the lead rules that 03:23 means literally "durable row for pin-export".
* PROPOSAL P-2: the claim route should pass `stage="claim"`/`decision=` for no-profile workflows, or `_resolve` should never mint when `decision` is None and the caller is `claim`. Needs lead ruling after F-2 is confirmed by execution.
* PROPOSAL P-3: add the masked-host-change limit to `docs/effective-configuration-binding.md` s10.

# Worker D - source identity review (read-only; no candidate test executed)
Machine-readable: `source-identity.json`. Supporting: `annexA_hash_check.json`, `runtime_authority_061_739.diff`.
Legend: VERIFIED = recomputed by git/sha256 from the existing clones; FINDING = discrepancy against a builder/handoff claim.

## 1. Identities
| Subject | Claimed | Result |
|---|---|---|
| Registry main | 2815643c3e15 | VERIFIED. Merge of PR #78; `run/reg-main` HEAD equal, clean. |
| Registry r08-v8 integration | 188e90efc02e | VERIFIED. Is the merge of PR #77 (parents 7cfeca80 [#75 merge], a40fe755 [#77 head]). Ancestor of main (main's first parent). Non-doc tree equal to main; only 2 docs differ (IMPLEMENTATION-CLOSEOUT, FAMILY-MIGRATION-PLAN-v1.1). |
| Registry PR heads | 75=ce45556b 78=6c84ad89 79=430fbbca | VERIFIED via refs/pull/N/head. #75, #78 are ancestors of main. #79 is NOT in main (merge-base = main; docs-only R1 head, open). |
| Control Plane main | 739efe7d8f16 | VERIFIED. Merge of #97 (parents e9214718 [#96 merge], 55488d2f [#97 head]). `run/cp` HEAD equal, `git status` clean (0 entries). |
| CP PR heads | 94=061a9865 95=b8fbe957 96=4adb84b9 97=55488d2f | VERIFIED. |
| Constitution | dcdbe3b76843 | VERIFIED (origin/main). 230c0af is its ancestor (dcdbe3b adds only LICENSE, orchestrator addendum, README lines, assignment schema). |

## 2. How D-07 reached CP main (checked with merge-base / first-parent / ancestry-path)
* First-parent chain: 739efe7 (#97) -> e921471 (#96) -> 19aeb93 (#94) -> b7eb11a (#93). `b8fbe95` (#95 head) is NOT on the first-parent chain. `fb9c7e0` (the #95 merge into the #94 branch, parents 061a986 + b8fbe95) is NOT an ancestor of main (confirmed).
* D-07 commits 2a96cfb, fb24ed0, ad794e1, b8fbe95 are NOT ancestors of e921471 (#96 merge) but ARE ancestors of 739efe7. Ancestry path from b8fbe95: 86148b6 (`Merge commit b8fbe95 into final3-integration-base`) -> 6f6e55b -> 88191f7 -> 739efe7. So D-07 is in main only through #97 history. VERIFIED.
* `git log --first-parent b7eb11a..739efe7 -- runtime_authority.py` = 739efe7 only. VERIFIED.
* Nuance: the assignment says "do not use the feature-branch merge of #95 as proof". Consistent: #95's head is in main's ancestry but only as a second-parent line of #97, never as a direct first-parent merge.

## 3. a1de48c vs main (builder claim of tree identity)
`git diff 739efe7 a1de48c --stat`: exactly one path, `docs/final3-consumers.md` (8 lines present on main, absent at a1de48c = the section 6 "integration repair" text added by 55488d2). Tree ids identical: src d248bde4, tests 889f7df4, schemas 2e927251. VERIFIED. This supports a justified identity argument for src/tests/schemas ONLY; it does not transfer any run result (CA07), and CI workflow `.github/**` was not part of the tree comparison (diff listed none).

## 4. Protected evaluators
Blob SHAs at 739efe7 == b7eb11a == 061a986 (and == 2a96cfb, b8fbe95) for: bounded.py 2cc8d998, freshness.py 0c4647f6, policy_binding.py 426d4779, rule_revision.py 9ca71a8d, reversibility.py a6be4bfe, holder_inventory.py 248e9304. VERIFIED.
runtime_authority.py: 739efe7 = 03b4efdf (sha256 45a27db8695f..., 500 lines); 061a986 = b7eb11a = 0b2c5e49 (sha256 a4b4ac36cca6..., 498 lines). `git diff 061a986 739efe7` = exactly ONE hunk, `@@ -401,16 +401,18 @@`, old lines 404-413 / new 404-415, 12+/10-. Diff file sha256 b776f6a4468221977e18ce5f3d6b8f32ffa393afca892748bae77643cfb1d8a7. The hunk removes `if binding is not None:` around the purpose-observation deadline-anchor block, de-indents it, and rewrites the comment. VERIFIED. (Other src changes 061a986..739efe7 are 8 non-protected files, listed in JSON.)

## 5. Annex A section 1 hash table (15 files)
All 15 rows (8 F3-A, 7 F3-B) match in git blob, sha256 and line count; working tree in run/cp equals the git blob. No mismatch. See `annexA_hash_check.json`. Annex's "exactly 10 changed files in src+.github" also VERIFIED (9 src files + tests.yml).
FINDING (minor, annex): Annex A says intermediate D-07 head `fb24ed0` is "not on main". FALSE: fb24ed0 is an ancestor of 739efe7 (it is in #97 history). fb24ed0 and 2a96cfb carry runtime_authority.py blob f9bca403 (sha256 ad7b95e5..., as the builder states).

## 6. Registry pins used by Control Plane tests / workflow
Tests (grep of run/cp/tests): `PIN`=6f600ab1 in test_f4_age_governance.py and test_f5_class_age_governance.py; `PIN`=943ab183 in test_v02_claim_policy_binding.py (skips if env missing; 6 of the 41 baseline failures); test_f5_class_unreadable_governance.py: PIN 6c3e5e40, PIN_V6 42a66632, PIN_V7 b73c59e6, PIN_V8 a40fe755, `ACCEPTED_PINS=(PIN,PIN_V6,PIN_V7,PIN_V8)`; final3_support.py additionally requires head == PIN_V8 (a40fe755) for test_final3_*; d06_support.py imports the composition suite (so D-06 binding files accept ACCEPTED_PINS). Docstrings in the D-06 files say "r08-v7 pin" but the code accepts v5-v8 (documentation drift, not an enforcement defect).
Workflow `.github/workflows/tests.yml` uses five pins: 6f600ab1 (F4, F5 class-age), 6c3e5e40 (F5 on_unreadable, composed), 42a66632 (revocation families), b73c59e6 (irreversibility), a40fe755 (final3 gate: junit `n >= 858`, skipped==0, failed==0). 943ab183 is NOT used by the workflow. FINDING: no workflow step runs `tests/test_effective_configuration_binding*.py` (the three D-06 files) under a pin with the skip-asserting junit gate (the final3 step at line 244 lists test_final3_*, irreversibility, revocation, composition, f5-unreadable only). Handoff section 4 says the same - CONFIRMED real.
Pin relation to Registry main (all exist in history, all ancestors of main): a40fe755 - non-doc tree IDENTICAL to main (12 doc files differ); b73c59e6 22 non-doc files differ; 42a66632 41; 6c3e5e40 61; 6f600ab1 76; 943ab183 116. So only a40fe755 (and 188e90e) is code-identical to main; the older pins are historical ancestors that are NOT code-identical. Registry main and 188e90e are rejected by ACCEPTED_PINS (static reading; not executed). Local checkouts `run/reg-*` all at the exact pin SHAs, clean.

## 7. Dependency pins / environment
* `pyproject.toml`: requires-python >=3.11; dependencies `pydantic>=2.12` only; optional `runtime-authority=[cryptography>=43]`; `dev` = pytest>=7, pytest-cov, pytest-asyncio>=0.23, cryptography>=43. No lock file in the Control Plane (no requirements*.txt/uv.lock/poetry.lock). PyNaCl is NOT declared in pyproject (needed by governed suites); the only lock is Registry `requirements-ed25519.lock.txt` (PyNaCl 1.6.2, hash-locked).
* `run/venv311` (Python 3.11.18): agent-control-plane 0.1.0 (editable -> run/cp), pydantic 2.14.2 (core 2.50.2), PyNaCl 1.6.2, cryptography 50.0.2, cffi 2.1.1, pytest 9.2.0, pytest-asyncio 1.4.1, pytest-cov 7.1.0, coverage 7.17.0, pluggy 1.7.0, setuptools 79.0.1.
* Environment difference to flag: the builder's baseline ran in a Python 3.13 scratch venv WITHOUT pytest-asyncio (cause of 35 of 41 baseline failures); venv311 HAS pytest-asyncio 1.4.1, so those tests may not fail here - a different environment from the builder's baseline; the lead must not assume the "41 identical failures" reproduce. UNVERIFIED until run.

# Worker B oracle notes (written BEFORE reading runtime_authority.py)
Source docs: Registry main 2815643, dir docs/family-migration/final-three/ (cited as 03 / 02 / 04 with file line numbers).

## 03 F3-B expectations (03:33-46)
E1 (03:37) Predecessor 061a986: anchor_deadline_to_inputs=True, no PolicyBinding, class bound 30 s, purpose observation accepted at age 30 s + 29 s stall => DISPATCHED (age 59 s). Successor: same fixture REFUSED by the EXISTING check_expired_before_dispatch; cached-purpose snapshot likewise; stall == remaining-bound boundary, and 1 s inside/outside behave exactly (strict boundary preserved).
E2 (03:38) Controls unchanged: grant status, identity, mandate anchoring; flag False byte-identical (no new anchoring); reversible and irreversible classes; post-reversal-window.
E3 (03:39) Outage extensions never raise a narrowed ceiling for ANY anchored input; cached-snapshot bound is the recorded bound.
E4 (03:40) Correction only adds a min: for any input new deadline <= old deadline; authorization accepted by new => accepted by old (no new permission/grace). "property test".
E5 (03:41) No new reason code; no change to profile dump, approval_commitment, catalogue_digest, persisted decision schema, refusal evidence fields; monotonic and wall-clock-stepped-back guards unchanged.
E6 (03:42) Destination apply never called after the deadline refusal.
E7 (03:43) ONLY authorized change in protected files; byte pins updated exactly for runtime_authority.py w/ new hash recorded; inverted characterization tests superseded by documented successor tests citing original results.
E8 (03:44) Interaction with profile-bearing families and policy_binding_unsupported unchanged.
Also 03:35 Subject includes unchanged-bytes pin of bounded.py, freshness.py, policy_binding.py, rule_revision.py, reversibility.py, holder_inventory.py. 03:46 OUT OF SCOPE: overflow defect (04).
03:17 bindings: qualifier defines own oracle; exact frozen heads only; no editing frozen oracle; record adverse results with original output.

## 02 freeze
02:14 D-07 = Option A, minimum protected-evaluator correction, file runtime_authority.py ONLY.
02:38 D-C4 moot: Option A authorized, "accepted residual" not taken.
02:66 (section 6) D-07 exact change: make the purpose-observation/cached-purpose deadline-anchoring block unconditional on PolicyBinding presence (remove `if binding is not None:` immediately before the block registering `collector` deadlines). Inner `collector is not None and cl is not None` test already limits to workflows with anchor_deadline_to_inputs=True. Pure `min` added; no commitment/persisted-schema/reason-code change; strictly more restrictive. Predecessor CP #94 (061a986) preserved unchanged; three *residual* characterization tests superseded by documented successor tests citing original results. If any other protected evaluator must change: STOP.
02:70 (section 7) bounded.py checks: future (observed_at > reference + tolerance) then stale (age > max_age), both strict `>`; missing ObservationPolicy remains hold observation_policy_missing. Overflow defect not introduced/fixed here.
02:18 NOT granted: other protected evaluators, new reason codes (02:31 says new durable code needs runtime-authority-reasons/0.4 + protected edit).

## 04 (OUT OF SCOPE)
04:1-10 DEF-OBS-TOL-OVERFLOW-1: ObservationPolicy.clock_tolerance_seconds huge (1e12, 1e30) => OverflowError in bounded._reconcile_observation (~:1922). Not fixed, not to be broadened into. My harness uses tolerance values only in normal range and must NOT assert on overflow.

## Gap in task numbering
The B1-B10 item list was in the lead's task text which I did not receive in full; I map B01..B10 to 03 E1-E8 + extras (see source-crosswalk.md).

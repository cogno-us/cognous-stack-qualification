# Mutation-adequacy oracle (Worker C)

Everything under "Builder results" is DEVELOPER evidence read from `run/cp/docs/evidence/`; nothing was re-run. Everything under "PROPOSAL" is an idea for the lead; the diff files in `work/C/mutants/` are DIFFS ONLY, generated from copies held in `work/C/_mutwork/a/` and checked with `patch -p1` plus `ast.parse` on scratch copies (never on `run/cp`).

## 1. Builder results (what exists, what survived, what it means)

| Run | Dir / log | Totals | Survivors |
|---|---|---|---|
| D-06 round 1 | `docs/evidence/d06/mutation/summary.json`, `mutation-run.log` | 49 mutants: 45 killed | `compare-only-digest`, `stamp-persisted-member` (2 more reported INVALID: `redundant-guard-removed`, `stamp-persisted-member-and-no-guard` = mutation text did not apply once; rerun in `mutation-extra`: both KILLED) |
| D-06 final2 (dedicated workflows added) | `mutation-final2/summary.json` | 64: 61 killed | `compare-only-digest`, `stamp-persisted-member`, `dedicated-age-host-digest-is-effective` |
| D-06 final3 (the head merged) | `mutation-final3/summary.json`, `mutation-final3-run.log`; extra `mutation-final3-extra/` | 67: 64 killed, control PASS | `compare-only-digest`, `stamp-persisted-member`, `cutoff-count-load-failure-ignored`. The third was killed AFTER the fact in `mutation-final3-extra` by a test added for it (`ECBD::test_d20`); `dedicated-age-host-digest-is-effective` of final2 was killed in final3 (by `ECBD::test_d19`) |
| D-07 | `docs/evidence/d07/mutation-results.json`, `mutation-run.log` | 16 (M01-M16): 16 KILLED behaviourally, static pins also "caught" | none |
| final3-consumers | `docs/evidence/final3-consumers/mutation-run.log`, `mutation-rerun.log` | first run 64: 59 killed, 5 survived (`anchor-skip-registry-record-check`, `anchor-skip-widening-check`, `obs-age-floor-zero`, `schema-revision-check-dropped`, `verified-skips-operational-check`); rerun of exactly those 5: 5 killed => reported "64/64" | after test additions |

Reading the survivors (my own assessment, from the harness source `docs/evidence/d06/mutation_harness.py` and logs):

1. `compare-only-digest` (SURVIVED, builder: "expected equivalent"). Agreed equivalent GIVEN `record_defect` runs first and recomputes the digest over the persisted members; digest equality then implies members equality up to SHA-256 collision. The companion `compare-only-digest-and-skip-recompute` is KILLED (`ECBU::test_digest_is_compared_in_addition_to_members_never_alone`). Residual risk: none beyond collision resistance.
2. `stamp-persisted-member` (SURVIVED alone). Not an equivalent mutant in intent (it turns a mismatch into equality), but the defensive guard in `GovernedLifecycle._resolve` (`status not in ACCEPTED and stamped.runtime_authority == persisted_ra` -> add `authorization_binding_changed`) catches it. Combined mutant `stamp-persisted-member-and-no-guard` is KILLED by `ECB::test_a05b`; guard alone removed (`redundant-guard-removed`) is KILLED by `ECB::test_d01[float_scalar]`. Result: two independent layers, each individually necessary only for a different input class; mutation adequacy for the layer "classification" in isolation is thus shown only by the combined mutant.
3. `cutoff-count-load-failure-ignored` and `dedicated-age-host-digest-is-effective`: real test gaps closed after the mutation round. The pattern (survivor -> new test -> killed) is normal but means the mutation score is partly fitted to the builder's mutant list.
4. Mutant design bias worth stating: builder's path mutants `skip-check-on-execute` and `skip-check-on-claim-path` are FAIL-CLOSED mutants (they remove the live member from the rebuilt binding, so EVERYTHING on that path refuses). They are killed by the POSITIVE-control tests (`ECB::test_g01`, execute tests that must succeed), not by a test that detects "a drifted configuration is now accepted". The fail-OPEN form of the claim/execute check (persisted member stamped, i.e. drift accepted) is exercised by the builder only through the two-path combined mutant `stamp-persisted-member-and-no-guard`. A per-path fail-open mutant (execute-only, pin-export-only, local-claim-only) is therefore the discriminating test of the independent harness (D06-M01..M04 below).
5. `accept-unknown-version` is KILLED only because `ECBU::test_an_unknown_version_is_unsupported_even_when_everything_else_is_consistent` asserts the STATUS LABEL (`version-unsupported` instead of `mismatch`; log `mutation-final3/accept-unknown-version.log`). At the OUTCOME level the mutant is equivalent: an unknown-version member still compares unequal to the live member so the base whole-dict equality refuses. The contract text (`02` L52) fixes the outcome, not the label.
6. D-07: builder mutants M09-M16 mutate the protected `bounded.py` in a scratch copy (allowed for mutation); all killed, and each run uses `-x` over a SELECTED subset (for M01: "1 failed, 7 passed, 2 deselected"), so the number of tests that would catch each mutant is not known.
7. final3-consumers: the five initial survivors show the original suite did not exercise: second strict parse of the Registry record in the anchor family, widening check in the anchor derivation, observation max-age floor 0, family schema-revision check, and the operational check of "verified". They were closed by added tests (not independently verified).

## 2. PROPOSAL: independent mutants to show the independent harness is not vacuous

Apply ONLY to a copy: `cp -a run/cp /tmp/<x>/cp-mut && cd /tmp/<x>/cp-mut && patch -p1 < <diff>` (exclude `.git`, set `PYTHONPATH=<copy>/src`, make sure the editable install of `run/cp` does not shadow the copy). Expectation column = what a non-vacuous independent harness must do. All are PROPOSALS (not part of the adopted contract).

| Diff | Meaning | Expected result of the INDEPENDENT harness |
|---|---|---|
| `D06-M01-execute-compare-deleted` | execute path only (stage != claim): persisted member stamped, classification skipped, drift/invalid/unknown-version accepted on execute | KILLED by A02, A06, A09 (execute leg); builder suite: killed by `ECB::test_c*` (all drift tests assert refusal) |
| `D06-M02-claim-stage-compare-deleted` | stage `claim` only (covers pin export AND local-claim issuance) | KILLED by A08 pin-export leg and C10 |
| `D06-M03-pin-export-compare-deleted` | `authorization_pin_export.py` only | KILLED by A08 pin-export leg; builder: `ECB::test_g02` |
| `D06-M04-local-claim-issuance-compare-deleted` | `local_authority_effect.py` only | KILLED only if the harness drives `materialize_local_execution_claim` (C10). EXPECTED TO SURVIVE the builder suite: no builder test drives that path (grep verified). A surviving M04 under the independent harness = the harness has the same blind spot |
| `D06-M05-ignore-identity-max-age` | live member reports constant 60 for `identity_max_age_seconds` | KILLED by A02 (identity scalar drift) |
| `D06-M06-ignore-scope-authority-domain` | scope.authority_domain constant | KILLED by A09 (authority_domain differs) |
| `D06-M07-ignore-family-effective-policy-digest` | `families[].effective_policy_digest` constant | KILLED by A05 (note: for profile-bearing families the changed effective value also changes the final profile and may be refused by base equality; the harness must assert the BINDING status/`reasons==[CODE]` path with an effective value change that leaves the final profile identical, if any such selection exists; otherwise this mutant may be partially masked: record that) |
| `D06-M08-ignore-family-contract-version` | contract_version constant `r08-v2` | KILLED only by a genuine second-contract case (C12) or the builder's in-process table patch (`ECB::test_c05`) |
| `D06-M09-accept-unknown-version` | version check removed + members-only compare + persisted member stamped on `bound` (outcome-visible form) | KILLED by A06; the single-edit form (version check only) is OUTCOME-EQUIVALENT and must not be counted as a harness miss |
| `D06-M10-legacy-accepted-at-cutoff` | `index <= cutoff` | KILLED by A07/A17 (record at index == cutoff must refuse) |
| `D06-M11-legacy-ignores-index` | any positive cutoff makes every member-less decision legacy | KILLED by A07/A15 |
| `D06-M12-legacy-without-cutoff` | default cutoff 0 still accepts index 0 as legacy | KILLED by A07 (default cutoff refuses) |
| `D06-M13-present-but-invalid-member-treated-as-legacy` | invalid-but-present member falls to the legacy rule AND legacy branch stamps the persisted member | KILLED by A18 (present-invalid member at index < cutoff must refuse); classify-only edit is outcome-equivalent (base equality) |
| `D07-M01-restore-binding-gate` | restore `if binding is not None:` (the original defect) | KILLED by B01, B02, B05, B21 |
| `D07-M02-gate-restored-cached-only` | live observation anchored, cached snapshot not (without binding) | KILLED by B02 (cached) but NOT by B01 (live) |
| `D07-M03-gate-restored-live-only` | cached snapshot anchored, live not | KILLED by B01 (live) but NOT by B02 |

Control mutants the independent harness should also include (no diff written; trivial): a no-op mutant (patch applying only a comment) must PASS the whole harness, to prove mutant application itself does not break the run; and for D-07, the harness must PASS on the unmutated tree and FAIL on the predecessor (`061a986`) tree for B01/B02/B03/B21 (the predecessor acts as a built-in mutant).

How the proposed mutants relate to builder coverage: M01, M03, M05-M07, M10-M12 have builder analogues (all KILLED in builder logs); M02/M04 (per-path fail-open) and M13/M09 (outcome-visible forms) are new; D07-M02/M03 split the builder's M02/M03 by the same axis.

## 3. Adverse/record notes

* Handoff PR #79 §6 itself records that the D-06 mutation counts differ between the draft (65 killed, 2 survived) and `summary.json` (64 killed, 3 survived). The files on disk (`mutation-final3/summary.json`) say 67 total / 64 killed / 3 survivors, one of which was later killed by an added test (`mutation-final3-extra`). I did not re-derive either number; treat "3 survived" as the on-disk fact and "2 effectively unresolved" as my reading.
* The consumer figure "64/64 killed" is the result AFTER a rerun of 5 survivors with newly added tests; the first run was 59/64 (`final3-consumers/mutation-run.log`).
* All mutation evidence uses the builder's own test selection and mutant list; none of it is independent qualification.

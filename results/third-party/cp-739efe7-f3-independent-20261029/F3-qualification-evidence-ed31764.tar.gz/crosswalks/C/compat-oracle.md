# Compatibility / byte-identity oracle (Worker C): probe usage, permitted differences, legacy-fixture plan

Status: `compat_probe.py` has been `py_compile`d only. It has NOT been run against anything (protocol not frozen). The baseline checkout exists at `work/C/baseline-cp` (detached `b7eb11aaeed9c766ecaae7d22955093f7f7cd1aa`, clean, `git status` empty, effective-configuration module absent) and has not been imported or executed.

## 1. Probe usage (after "PROTOCOL FROZEN" only)

```
PY=.../scratchpad/run/venv311/bin/python
$PY work/C/compat_probe.py --src work/C/baseline-cp/src --out work/C/probe-baseline.json
$PY work/C/compat_probe.py --src run/cp/src            --out work/C/probe-main.json      # read-only on run/cp (PYTHONDONTWRITEBYTECODE is set by the probe)
$PY work/C/compat_probe.py --diff work/C/probe-baseline.json work/C/probe-main.json
```
The child runs under `python -I` with the given `src` first on `sys.path` and ABORTS if `agent_control_plane.__file__` is not under that `src` (the venv has an editable install of `run/cp`; this catches shadowing in the baseline run). The `--diff` mode imports nothing.

What it records, and the verdict rule I propose (PROPOSAL; adopted contract = `03` L27 and `02` L56):

| Probe key | Baseline vs main must be |
|---|---|
| `profile_fixtures.*` (dump JSON, sha256, `catalogue_digest`) | IDENTICAL (three fixed `RuntimeAuthorityProfile` variants: minimal, `freshness` default, `freshness` with `anchor_deadline_to_inputs=True`). The dump omits default-False flags by `exclude_if`, so `freshness_default` guards that D-06/D-07 did not change a default |
| `approval_commitment.*` | IDENTICAL |
| `schema_files_sha256` (every file under `<repo>/schemas`, `<repo>/conformance`) | IDENTICAL (git already shows no change under `schemas/` or `conformance/` between `b7eb11a` and `739efe7`) |
| `reason_vocabulary` (`CODES_ADDED_IN_0_2/0_3`, `REGISTRY_SHA256`, each published registry's `codes` and its order hash, `vocabulary_for` samples, string constants of `runtime_authority.py`) | IDENTICAL for registries/labels/code sets. `runtime_authority_string_constants` must differ in AT MOST nothing (the D-07 edit removes an `if` and adds a comment; no string literal added). Any difference is a finding |
| `commitment_selfcheck` | IDENTICAL |
| `model_json_schemas_sha256` (pydantic schemas of RuntimeDecision, TenantAuthorizationBinding, EffectTimeRefusal, EffectAttempt, EffectObservation, ResolutionInput, ResolutionCheck, RuntimeProposal, ObservationPolicy, RuntimeAuthorityProfile, ActionClass, PurposeStatus) | IDENTICAL (covers "persisted decision schema or refusal evidence fields", `03` L41; the opaque `runtime_authority` dict is typed `dict`, so the added member is invisible to the schema BY DESIGN of carriage C2) |
| `effective_policy_snapshot.identity_digest`, `identity_digest_empty` | IDENTICAL |
| `effective_policy_snapshot.FAMILY_TABLE` / `SCHEMA_REVISIONS` | ADDITIVE ONLY: main adds `anchor_deadline`, `observation_max_age`, `observation_clock_tolerance` (rows) and three schema revisions; every baseline row unchanged (git diff of `registry_effective_policy.py` shows exactly this) |
| `protected_sha256` | six IDENTICAL (`bounded freshness policy_binding rule_revision reversibility holder_inventory`); `runtime_authority.py` differs exactly once: baseline `a4b4ac36cca6e75d8fc3408b8738163acfb609a7265633aec2f799700ff9ea66` -> main `45a27db8695ff9d23516e1937f3bafa2391bbc1587ed0fb09f56ea8f3e01d23f` (both values already verified here by `git show <rev>:... | sha256sum`; the probe re-derives them from the working trees) |
| `all_modules_sha256` | main adds `effective_configuration_binding.py`, `registry_final3_governance.py`; changes `registry_effective_policy.py`, `registry_f4_age_governance.py`, `registry_f5_class_age_governance.py`, `registry_f5_class_unreadable_governance.py`, `registry_governed_lifecycle.py`, `registry_governed_policy.py`, `runtime_authority.py` (as `git diff --stat b7eb11a 739efe7 -- src` shows); ANY other module difference is a finding |

Not covered by the probe (other cases): `RuntimeAuthorityProfile` with `policy_binding`/`operation_identity`/`reversibility` variants (needs constructing larger fixtures; add if the lead wants more variants), Registry-side r08-v1..v7 identities (C14), behaviour.

## 2. Registry-side compatibility (read-only note; execution after freeze)

`diff -rq run/reg-b73c59e run/reg-v8` (non-docs): new `registry_successor/engine/families_{anchor,observation}.py`, `v8_decision.py`, `v8_families.py`, `v8_policy_identity.py`; changed `engine/identity.py` (adds a `scalar-int` branch), `engine/profile.py`, `engine/profiles.py` (adds `V8`); changed tests `test_r08v7_frozen_baseline.py` (ENGINE_MODULES allowlist gets the two new modules) and `test_ext_s1_5_identity_module.py` (allowlist gets five new module paths). PROPOSAL for C14: run the `b73c59e` copies of those two tests, unedited, against the `reg-v8` tree; failures other than the allowlist assertions are findings. Also confirm `V8` is not in `PROFILES` and v1..v7 vector files under `tests/vectors/` are byte-identical (`diff -rq` shows no difference outside `r08v8`).

## 3. Legacy-fixture plan (F3-A expectation 4; also feeds expectation 5)

Why independent: the builder's six frozen stores (`tests/fixtures/d06_legacy_store_*.json`) are committed by the builder, generated by `docs/evidence/d06/gen_legacy_fixture.py` through the builder's own test helper modules (`tests.test_governed_policy_composition`) on `b7eb11a`. Their provenance is a claim. The independent plan regenerates stores with the UNCHANGED prior binary using ONLY public classes.

Step G (generate, after freeze, against `work/C/baseline-cp` only; never import `run/cp`):
1. Interpreter `python -I`, `sys.path = [baseline-cp/src]`, assert `agent_control_plane.__file__` under `work/C/baseline-cp/src` and `effective_configuration_binding` NOT importable. Registry material: the baseline governed suites run under the **r08-v7 pin = `run/reg-b73c59e`** (`OCS_REGISTRY_PIN_DIR=run/reg-b73c59e`, `OCS_REQUIRE_REGISTRY_PIN=1`; the builder's own scripts call this `pin_v7`); the older class-age/F4 suites used `reg-6f600ab`. The lead must confirm `reg-b73c59e` contains r08-v1..v7 (it lists `r08-v7-contract.md`).
2. For each of: composed (F4 + class age + class unreadable, profile-bearing), F4-only without profile, dedicated F4, dedicated class-age, dedicated class-unreadable, dedicated joint: build the workflow with the baseline classes, `decide` THREE proposals in sequence (so cutoff cases 0, 1, 2, 3 are meaningful: indexes 0,1,2), keep one authorized decision at each index, and for one store leave a decision executed and one failed (to test "an attempt already failed still blocks retry" on a legacy record). Record at generation time, from the BASELINE objects: `decision_id`, `effect_id`, `binding.runtime_authority` verbatim, `approval_commitment`, `catalogue_digest` (recompute with `commitment(profile.model_dump(mode="json"))`), sha256 of `run.json`, and the set of top-level keys of `runtime_authority` (must be exactly the six legacy keys; `None` for the profile-less store).
3. Freeze the stores read-only (chmod a-w) and record their sha256 in the harness; the harness copies them into a temp dir per case.
4. A pin-export-capable legacy store (profile with `policy_binding`, as `d06_support.pin_prepared`) is also required: build it with the baseline classes so claim-path legacy handling (`authorization_pin_export`, local claim issuance) can be replayed.

Step R (replay on main, `run/cp`, after freeze): for each store and each cutoff in {omitted(0), 1, 2, 3, count, count+1, True, -1, 2**31}:
* below cutoff: execute succeeds, `configuration_binding_status == "legacy"`, destination `apply` count 1, recomputed `approval_commitment` and `catalogue_digest` equal the values recorded at generation (byte identity, expectation 4/5);
* index at/after cutoff or cutoff 0: refusal `authorization_binding_changed`, durable `EffectTimeRefusal`, destination untouched;
* cutoff > count and invalid types: construction refused `legacy_cutoff_invalid` (record the observed rule; see `ambiguities.md` Q4);
* the failed-attempt record still blocks automatic retry;
* the same replay through pin export / local claim issuance for the pin-capable store;
* separate process: each replay in a fresh `python -I` child.

Step O (old binary on a NEW record, expectation 5 "legacy binary on new record fails CLOSED"; stronger than the builder's `ECBL::test_b01`, which uses the unchanged plain `BoundedAuthorizationWorkflow` of the NEW tree): after freeze, generate a new record with main's governed workflow (composed, F4+age+unreadable), then open the SAME store directory with the `b7eb11a` classes (`registry_governed_policy.GovernedPolicyWorkflow` of `baseline-cp`, and the plain `BoundedAuthorizationWorkflow`) in a separate interpreter and call `execute` and `assess_authorization_pin`. Expected: `PermissionError("authorization-critical inputs changed before effect")`, a durable `EffectTimeRefusal` with `authorization_binding_changed`, destination untouched. Note the old reader's `RuntimeDecision` pydantic model must parse the new store (the member lives in the opaque dict, so it should); if it does NOT parse, record "fails closed by parse error" separately and do not count it as the designed mechanism.

Step M (mixed fleet, limit L4): with the old binary append a NEW decision to a store already upgraded by main (old writer after the cutoff), then check main refuses it past the cutoff and the old binary executes it (documented limitation). Expected and recorded as a limit, not a defect.

Everything in G/O/M uses synthetic fixtures only; no network; no paid calls.
